(()=>{var F={74384:(o,f,l)=>{"use strict";var h=l(74296),g=l(86006),p=l(48521),y=l(39573),E=l(96774),b=l(71742),w=l(53169);const j=w.ZP.ul`
  list-style: none;
  padding: 0;

  li {
    height: 2.5em;

    display: flex;
    justify-content: space-between;
    align-items: center;

    &:not(:first-child) {
      border-top: 1px dashed #eeeeee;
    }

    a {
      color: inherit;
    }

    color: #000000;

    &[data-selected='false'] {
      color: #bbbbbb;

      &:hover {
        color: #555555;
      }
    }

    svg {
      font-size: 1.2em;
      transform: translateY(0.17em);
    }

    img {
      width: 1.2em;
      height: 1.2em;
      transform: translateY(0.17em) scale(1.2);
    }

    i {
      margin-right: ${({iconMarginRight:e="0.2em"})=>e};
    }

    span {
      display: inline-block;

      &:first-letter {
        text-transform: ${({firstLetterUpperCase:e=!0})=>e?"uppercase":"none"};
      }
    }

    button {
      border: none;
      outline: none;
      background-color: transparent;
      padding: 0;

      cursor: pointer;

      color: #bbbbbb;

      &:hover {
        color: #555555;
      }
    }
  }
`;var M=l(82298),Ee=l(64822),Z=l(30816).Buffer,Ce=Object.defineProperty,Oe=Object.prototype.hasOwnProperty,G=Object.getOwnPropertySymbols,Pe=Object.prototype.propertyIsEnumerable,V=(e,t,r)=>t in e?Ce(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r,X=(e,t)=>{for(var r in t||(t={}))Oe.call(t,r)&&V(e,r,t[r]);if(G)for(var r of G(t))Pe.call(t,r)&&V(e,r,t[r]);return e},P;(function(e){e.PROGRESS="progress",e.SUCCEED="succeed",e.FAIL="fail",e.DENIED="denied"})(P||(P={}));function Tt(e){var t,r,a;return{msgs:e.msgs.map(s=>s.toJSON()),fee:(t=e.fee)==null?void 0:t.toJSON(),memo:e.memo,gasPrices:(r=e.gasPrices)==null?void 0:r.toString(),gasAdjustment:(a=e.gasAdjustment)==null?void 0:a.toString(),account_number:e.account_number,sequence:e.sequence,feeDenoms:e.feeDenoms}}function Y(e){return X(X({},e),{msgs:e.msgs.map(t=>M.Msg.fromData(JSON.parse(t))),fee:e.fee?M.StdFee.fromData(JSON.parse(e.fee)):void 0})}function Se(e,t,r){return new Ee.y(a=>{const s=new M.LCDClient({chainID:t.chainID,URL:t.servers.lcd,gasPrices:r.gasPrices,gasAdjustment:r.gasAdjustment}),{privateKey:i}=e,x=new M.RawKey(Z.from(i,"hex"));s.wallet(x).createAndSignTx(Y(r)).then(d=>s.tx.broadcastSync(d)).then(d=>{(0,M.isTxError)(d)?(a.next({status:P.FAIL,error:new Error(d.raw_log)}),a.complete()):(a.next({status:P.SUCCEED,payload:{txhash:d.txhash,height:d.height,raw_log:d.raw_log}}),a.complete())}).catch(d=>{a.next({status:P.FAIL,error:d}),a.complete()})})}var We=l(76679),S=l.n(We);const _=256,Q=100;function Dt(e,t){try{const r=CryptoJS.lib.WordArray.random(128/8),a=CryptoJS.PBKDF2(t,r,{keySize:_/32,iterations:Q}),s=CryptoJS.lib.WordArray.random(128/8),i=CryptoJS.AES.encrypt(e,a,{iv:s,padding:CryptoJS.pad.Pkcs7,mode:CryptoJS.mode.CBC});return r.toString()+s.toString()+i.toString()}catch(r){return""}}function Ie(e,t){try{const r=S().enc.Hex.parse(e.substr(0,32)),a=S().enc.Hex.parse(e.substr(32,32)),s=e.substring(64),i=S().PBKDF2(t,r,{keySize:_/32,iterations:Q});return S().AES.decrypt(s,i,{iv:a,padding:S().pad.Pkcs7,mode:S().mode.CBC}).toString(S().enc.Utf8)}catch(r){return""}}function Nt(){return new MnemonicKey({coinType:330})}function Bt(e){return new MnemonicKey({mnemonic:e,coinType:330})}function kt(e){var t,r;return{privateKey:e.privateKey.toString("hex"),publicKey:(r=(t=e.publicKey)==null?void 0:t.toString("hex"))!=null?r:"",terraAddress:e.accAddress}}function zt(e,t){return encrypt(JSON.stringify(e),t)}function je(e,t){return JSON.parse(Ie(e,t))}var n=l(27378);const W=700,I=380,Me=I/W;var Ae=Object.defineProperty,q=Object.prototype.hasOwnProperty,D=Object.getOwnPropertySymbols,ee=Object.prototype.propertyIsEnumerable,te=(e,t,r)=>t in e?Ae(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r,Le=(e,t)=>{for(var r in t||(t={}))q.call(t,r)&&te(e,r,t[r]);if(D)for(var r of D(t))ee.call(t,r)&&te(e,r,t[r]);return e},Te=(e,t)=>{var r={};for(var a in e)q.call(e,a)&&t.indexOf(a)<0&&(r[a]=e[a]);if(e!=null&&D)for(var a of D(e))t.indexOf(a)<0&&ee.call(e,a)&&(r[a]=e[a]);return r};function De(e){var{variant:t,borderRadius:r,children:a}=e,s=Te(e,["variant","borderRadius","children"]);return n.createElement("svg",Le({viewBox:`0 0 ${W} ${I}`},s),a)}const Ne=(0,w.ZP)(De)`
  border-radius: ${({variant:e="medium",borderRadius:t=e==="medium"?30:20})=>t}px;

  background-color: #ffffff;
  border: 3px dashed #aaaaaa;

  svg {
    color: #aaaaaa;
  }
`;var Be=Object.defineProperty,re=Object.prototype.hasOwnProperty,N=Object.getOwnPropertySymbols,ne=Object.prototype.propertyIsEnumerable,ae=(e,t,r)=>t in e?Be(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r,ke=(e,t)=>{for(var r in t||(t={}))re.call(t,r)&&ae(e,r,t[r]);if(N)for(var r of N(t))ne.call(t,r)&&ae(e,r,t[r]);return e},ze=(e,t)=>{var r={};for(var a in e)re.call(e,a)&&t.indexOf(a)<0&&(r[a]=e[a]);if(e!=null&&N)for(var a of N(e))t.indexOf(a)<0&&ne.call(e,a)&&(r[a]=e[a]);return r};function Re(e){var{variant:t="medium",borderRadius:r,textColor:a}=e,s=ze(e,["variant","borderRadius","textColor"]);return n.createElement("svg",ke({viewBox:`0 0 ${W} ${I}`},s))}const Ze=(0,w.ZP)(Re)`
  box-shadow: 0 2px 6px 2px rgba(0, 0, 0, 0.43);

  border-radius: ${({variant:e="medium",borderRadius:t=e==="medium"?30:20})=>t}px;

  text {
    font-family: sans-serif;
    fill: ${({textColor:e="#ffffff"})=>e};
  }
`;var Je=l(78781);function $e({name:e,terraAddress:t,variant:r}){return r==="medium"?n.createElement(n.Fragment,null,n.createElement("text",{x:60,y:250,fontSize:23,opacity:.7},t),n.createElement("text",{x:60,y:300,fontSize:35},e)):n.createElement(n.Fragment,null,n.createElement("text",{x:60,y:220,fontSize:40,opacity:.7},(0,Je.truncate)(t)),n.createElement("text",{x:60,y:300,fontSize:60},e))}var Ke=Object.defineProperty,le=Object.prototype.hasOwnProperty,B=Object.getOwnPropertySymbols,oe=Object.prototype.propertyIsEnumerable,se=(e,t,r)=>t in e?Ke(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r,Fe=(e,t)=>{for(var r in t||(t={}))le.call(t,r)&&se(e,r,t[r]);if(B)for(var r of B(t))oe.call(t,r)&&se(e,r,t[r]);return e},Ue=(e,t)=>{var r={};for(var a in e)le.call(e,a)&&t.indexOf(a)<0&&(r[a]=e[a]);if(e!=null&&B)for(var a of B(e))t.indexOf(a)<0&&oe.call(e,a)&&(r[a]=e[a]);return r};function He(e){var{design:t,name:r,terraAddress:a,variant:s="medium",ref:i}=e,x=Ue(e,["design","name","terraAddress","variant","ref"]);const d=(0,n.useMemo)(()=>(0,n.isValidElement)(t)?t:t==="anchor"?n.createElement("image",{xlinkHref:"/assets/wallet/Anchor.svg",width:W,height:I}):t==="terra"?n.createElement("image",{xlinkHref:"/assets/wallet/Terra.svg",width:W,height:I}):typeof t=="string"?n.createElement("rect",{fill:t,width:W,height:I}):n.createElement("image",{xlinkHref:"/assets/wallet/Terra.svg",width:W,height:I}),[t]);return n.createElement(Ze,Fe({variant:s},x),d,n.createElement($e,{name:r,terraAddress:a,variant:s}))}var Ge=l(81347),Ve=Object.defineProperty,ie=Object.prototype.hasOwnProperty,k=Object.getOwnPropertySymbols,ce=Object.prototype.propertyIsEnumerable,de=(e,t,r)=>t in e?Ve(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r,Xe=(e,t)=>{for(var r in t||(t={}))ie.call(t,r)&&de(e,r,t[r]);if(k)for(var r of k(t))ce.call(t,r)&&de(e,r,t[r]);return e},Ye=(e,t)=>{var r={};for(var a in e)ie.call(e,a)&&t.indexOf(a)<0&&(r[a]=e[a]);if(e!=null&&k)for(var a of k(e))t.indexOf(a)<0&&ce.call(e,a)&&(r[a]=e[a]);return r};function _e(e){var{cardWidth:t,children:r,selectedIndex:a,onSelect:s,onCreate:i}=e,x=Ye(e,["cardWidth","children","selectedIndex","onSelect","onCreate"]);const d=(0,n.useMemo)(()=>{if(!r)return null;const m=Array.isArray(r)?r:[r];return m.length===0?null:m.map((u,v)=>{const C=t*(v-a),O=1-Math.abs((v-a)*.2),R=1-Math.abs((v-a)*.4);return n.createElement("li",{key:"card"+v,onClick:()=>a!==v&&s(v),style:{transform:`translateX(${C}px) scale(${O})`,opacity:R,filter:Math.abs(v-a)===1?"blur(2px)":void 0,cursor:a!==v?"pointer":void 0}},u)})},[t,r,s,a]);return n.createElement("ul",Xe({},x),d||(typeof i=="function"?n.createElement("li",{onClick:i,style:{cursor:"pointer"}},n.createElement(Ne,null,n.createElement("g",{transform:"translate(350 190)"},n.createElement("g",{transform:"translate(-100 -100)"},n.createElement(Ge.Z,{width:"200",height:"200"}))))):null))}const Rt=(0,w.ZP)(_e)`
  list-style: none;
  padding: 0;

  position: relative;

  min-width: ${({cardWidth:e})=>e}px;
  max-width: ${({cardWidth:e})=>e}px;
  height: ${({cardWidth:e})=>Math.ceil(e*Me)}px;

  > li {
    position: absolute;
    left: 0;
    top: 0;

    user-select: none;

    > svg {
      width: ${({cardWidth:e})=>e}px;
    }

    will-change: transform, opacity, filter;
    transition: transform 0.3s ease-in-out, opacity 0.3s;
  }
`;var Zt=l(66471),J=l(1532);function Jt(e){return new Observable(t=>{if(browser.runtime.getURL("").startsWith("safari-web-extension://")){let r=null;const a=interval(1e3).subscribe(()=>{browser.storage.local.get(e).then(s=>{const i=s[e];r!==null&&deepEqual(r,i)||(r=i,t.next(i))})});return()=>{a.unsubscribe()}}})}var A=(e,t,r)=>new Promise((a,s)=>{var i=m=>{try{d(r.next(m))}catch(u){s(u)}},x=m=>{try{d(r.throw(m))}catch(u){s(u)}},d=m=>m.done?a(m.value):Promise.resolve(m.value).then(i,x);d((r=r.apply(e,t)).next())});const L="terra_wallet_storage_v1";function T(){return A(this,null,function*(){var e;return(e=(yield J.browser.storage.local.get(L))[L])!=null?e:[]})}function $(e){return A(this,null,function*(){yield browser.storage.local.set({[L]:e})})}function Qe(e){return A(this,null,function*(){return(yield T()).find(r=>r.terraAddress===e)})}function $t(e){return A(this,null,function*(){const r=[...yield T(),e];yield $(r)})}function Kt(e){return A(this,null,function*(){const r=(yield T()).filter(({terraAddress:a})=>a!==e.terraAddress);yield $(r)})}function Ft(e,t){return A(this,null,function*(){const r=yield T(),a=r.findIndex(i=>i.terraAddress===e);if(a===-1)return;const s=[...r];s.splice(a,1,t),yield $(s)})}function Ut(){return new Observable(e=>{function t(a,s){if(s==="local"&&a[L]){const{newValue:i}=a[L];e.next(i!=null?i:[])}}browser.storage.onChanged.addListener(t);const r=safariWebExtensionStorageChangeListener(L).subscribe(a=>{e.next(a!=null?a:[])});return T().then(a=>{e.next(a)}),()=>{browser.storage.onChanged.removeListener(t),r.unsubscribe()}})}var qe=l(31542),et=l(65785);class tt extends n.Component{constructor(t){super(t);this.state={error:null}}static getDerivedStateFromError(t){return{error:t}}componentDidCatch(t,r){this.setState({error:t}),console.error(r)}render(){return this.state.error?n.createElement(rt,null,this.state.error.toString()):this.props.children}}const rt=w.ZP.pre`
  width: 100%;
  max-height: 500px;
  overflow-y: auto;
  font-size: 12px;
`,nt=w.vJ`
  html,
  body {
    margin: 0;
    background-color: ${({backgroundColor:e})=>e!=null?e:"#0c3694"}
  }
  
  
  html {
    font-family: 'Segoe UI', 'Roboto', 'Oxygen',
    'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue',
    sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    font-size: 16px;
    word-spacing: 1px;
    -ms-text-size-adjust: 100%;
    -webkit-text-size-adjust: 100%;
    box-sizing: border-box;
  }
  
  *,
  *::before,
  *::after {
    box-sizing: border-box;
    margin: 0;
    font-family: 'Segoe UI', 'Roboto', 'Oxygen',
    'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue',
    sans-serif;
  }
  
  ::-webkit-scrollbar {
    display: none;
  }
  
  input::-webkit-outer-spin-button,
  input::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
  }
`;var at=l(9031),lt=l(9969);function ot({className:e,tx:t}){return n.createElement("ul",{className:e},t==null?void 0:t.msgs.map((r,a)=>n.createElement(st,{key:"msg"+a,msg:r})))}function st({msg:e}){const[t,r]=(0,n.useState)(!1);return e instanceof M.MsgExecuteContract?n.createElement("li",null,n.createElement("h3",{onClick:()=>r(a=>!a)},n.createElement("span",null,"MsgExecuteContract"),t?n.createElement(at.Z,null):n.createElement(lt.Z,null)),t&&n.createElement("ul",null,n.createElement("li",null,n.createElement("h4",null,"Sender"),n.createElement("p",null,e.sender)),n.createElement("li",null,n.createElement("h4",null,"Contract"),n.createElement("p",null,e.contract)),n.createElement("li",null,n.createElement("h4",null,"execute_msg"),n.createElement("pre",null,JSON.stringify(e.execute_msg,null,2))),n.createElement("li",null,n.createElement("h4",null,"Coins"),n.createElement("p",null,e.coins.toJSON())))):null}const it=(0,w.ZP)(ot)`
  list-style: none;
  padding: 0;

  margin: 20px 0;

  > li {
    &:not(:first-child) {
      margin-top: 10px;
    }

    border-radius: 8px;
    border: 1px solid #81a2cb;
    background-color: #f7fbff;

    padding: 10px;

    h3 {
      font-size: 1em;

      user-select: none;
      cursor: pointer;

      display: flex;
      justify-content: space-between;
      align-items: center;

      svg {
        font-size: 1.2em;
      }
    }

    ul {
      margin-top: 15px;

      list-style: none;
      padding: 0;

      li {
        h4 {
          margin-bottom: 5px;
        }

        p,
        pre {
          font-size: 1em;
        }

        &:not(:first-child) {
          margin-top: 10px;
        }
      }
    }
  }
`;var ue=l(56490),ct=l(78693),fe=l.n(ct),dt=l(80082),ut=l.n(dt),ft=Object.defineProperty,pt=Object.prototype.hasOwnProperty,pe=Object.getOwnPropertySymbols,mt=Object.prototype.propertyIsEnumerable,me=(e,t,r)=>t in e?ft(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r,ve=(e,t)=>{for(var r in t||(t={}))pt.call(t,r)&&me(e,r,t[r]);if(pe)for(var r of pe(t))mt.call(t,r)&&me(e,r,t[r]);return e};const vt=["en-US","ko-KR"],gt=fe(),ht=ve(ve({},fe()),ut());function Ht(e){switch(e){case"en":case"ko":return!0}return!1}const z=(0,n.createContext)();function yt({children:e}){const t=(0,n.useMemo)(()=>(0,ue.getBrowserLocale)({fallbackLanguageCodes:["en-US"]}),[]),{locale:r,updateLocale:a}=(0,ue.useLocale)(t);return n.createElement(z.Provider,{value:{locale:r,locales:vt,updateLocale:a}},e)}function Gt(){return useContext(z)}function wt(){const{locale:e}=(0,n.useContext)(z);return{locale:e.substr(0,2),messages:e==="ko-KR"?ht:gt}}const Vt=z.Consumer;var xt=l(47290),bt=l(45530);function Et({children:e,injectFirst:t=!0,theme:r}){return n.createElement(xt.ZP,{injectFirst:t},n.createElement(w.f6,{theme:r},n.createElement(bt.Z,{theme:r},e)))}const Xt=[{name:"mainnet",chainID:"columbus-4",servers:{lcd:"https://lcd.terra.dev",fcd:"https://fcd.terra.dev",ws:"wss://fcd.terra.dev",mantle:"https://mantle.anchorprotocol.com/"}},{name:"testnet",chainID:"tequila-0004",servers:{lcd:"https://tequila-lcd.terra.dev",fcd:"https://tequila-fcd.terra.dev",ws:"wss://tequila-ws.terra.dev",mantle:"https://tequila-mantle.anchorprotocol.com/"}}],ge="tx-",Yt="content-",_t=e=>/^tx-[0-9]+$/.test(e),Qt=e=>/^content-[0-9]+$/.test(e),qt=e=>e.substr(3),er=e=>e.substr(8),tr=400,rr=50,nr=550,ar=20,lr=null;var Ct=Object.defineProperty,Ot=Object.prototype.hasOwnProperty,he=Object.getOwnPropertySymbols,Pt=Object.prototype.propertyIsEnumerable,ye=(e,t,r)=>t in e?Ct(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r,K=(e,t)=>{for(var r in t||(t={}))Ot.call(t,r)&&ye(e,r,t[r]);if(he)for(var r of he(t))Pt.call(t,r)&&ye(e,r,t[r]);return e},St=(e,t,r)=>new Promise((a,s)=>{var i=m=>{try{d(r.next(m))}catch(u){s(u)}},x=m=>{try{d(r.throw(m))}catch(u){s(u)}},d=m=>m.done?a(m.value):Promise.resolve(m.value).then(i,x);d((r=r.apply(e,t)).next())});function Wt({className:e}){const t=(0,n.useMemo)(()=>{try{const u=window.location.search,v=new URLSearchParams(u),C=v.get("id"),O=v.get("terraAddress"),R=v.get("tx"),we=v.get("network"),xe=v.get("origin"),be=v.get("timestamp");if(!C||!O||!R||!we||!xe||!be)return;const At=JSON.parse(atob(R)),Lt=JSON.parse(atob(we));return{id:C,terraAddress:O,network:Lt,serializedTx:At,origin:xe,timestamp:new Date(parseInt(be))}}catch(u){return}},[]),r=(0,n.useMemo)(()=>(t==null?void 0:t.serializedTx)?Y(t==null?void 0:t.serializedTx):void 0,[t==null?void 0:t.serializedTx]),[a,s]=(0,n.useState)(""),[i,x]=(0,n.useState)(void 0);(0,n.useEffect)(()=>{!t||Qe(t.terraAddress).then(u=>x(u))},[t]);const d=(0,n.useCallback)(u=>St(this,null,function*(){const v=je(u.encryptedWallet.encryptedWallet,u.password),C=J.browser.runtime.connect(void 0,{name:ge+u.id});Se(v,u.network,u.serializedTx).subscribe(O=>{C.postMessage(O)},O=>{C.postMessage({status:P.FAIL,error:O})},()=>{C.disconnect()})}),[]),m=(0,n.useCallback)(u=>{const v=J.browser.runtime.connect(void 0,{name:ge+u.id});v.postMessage({status:P.DENIED}),v.disconnect()},[]);return t?i?n.createElement("section",{className:e},n.createElement("header",null,n.createElement(He,{className:"wallet-card",name:i.name,terraAddress:i.terraAddress,design:i.design})),n.createElement(j,{className:"wallets-actions",iconMarginRight:"0.6em",firstLetterUpperCase:!1},n.createElement("li",null,n.createElement("div",null,n.createElement("i",null,n.createElement(y.Z,null)),n.createElement("span",null,"NETWORK")),n.createElement("span",null,t.network.name," (",t.network.chainID,")")),n.createElement("li",null,n.createElement("div",null,n.createElement("i",null,n.createElement(E.Z,null)),n.createElement("span",null,"ORIGIN")),n.createElement("span",null,t.origin)),n.createElement("li",null,n.createElement("div",null,n.createElement("i",null,n.createElement(b.Z,null)),n.createElement("span",null,"TIMESTAMP")),n.createElement("span",null,t.timestamp.toLocaleString()))),n.createElement(it,{tx:r,className:"tx"}),n.createElement("section",{className:"form"},n.createElement(h.Z,{variant:"outlined",type:"password",size:"small",fullWidth:!0,label:"WALLET PASSWORD",InputLabelProps:{shrink:!0},value:a,onChange:({target:u})=>s(u.value)})),n.createElement("footer",null,n.createElement(g.Z,{variant:"contained",color:"secondary",onClick:()=>m(K({},t))},"Deny"),n.createElement(g.Z,{variant:"contained",color:"primary",disabled:a.length===0,onClick:()=>d(K(K({},t),{password:a,encryptedWallet:i}))},"Submit")),n.createElement(nt,{backgroundColor:"#ffffff"})):n.createElement("div",{className:e},"\uC9C0\uAC11\uC774 \uC5C6\uC74C"):n.createElement("div",{className:e},"Can't find Transaction!")}const It=(0,w.ZP)(Wt)`
  max-width: 100vw;

  padding: 20px;

  header {
    display: flex;
    justify-content: center;

    .wallet-card {
      width: 280px;
    }

    margin-bottom: 30px;
  }

  .tx {
    margin: 30px 0;
  }

  .form {
    margin: 30px 0;
  }

  footer {
    display: flex;

    > * {
      flex: 1;

      &:not(:first-child) {
        margin-left: 10px;
      }
    }
  }
`,jt=(0,p.Z)();function Mt(){const{locale:e,messages:t}=wt();return n.createElement(et.Z,{locale:e,messages:t},n.createElement(Et,{theme:jt},n.createElement(It,null)))}(0,qe.render)(n.createElement(tt,null,n.createElement(yt,null,n.createElement(Mt,null))),document.querySelector("#app"))},78693:o=>{o.exports={"wallet.change-password":"Change password","wallet.delete":"Delete wallet","wallet.recover":"Recover existing wallet","wallet.new":"New wallet","wallet.empty":"Please add a new wallet","locale.en-US":"English","locale.ko-KR":"Korean"}},80082:o=>{o.exports={"wallet.change-password":"\uBE44\uBC00\uBC88\uD638 \uBCC0\uACBD","wallet.delete":"\uC9C0\uAC11 \uC0AD\uC81C","wallet.recover":"\uAE30\uC874 \uC9C0\uAC11 \uBCF5\uC6D0\uD558\uAE30","wallet.new":"\uC0C8 \uC9C0\uAC11","wallet.empty":"\uC9C0\uAC11\uC774 \uC5C6\uC2B5\uB2C8\uB2E4. \uC0C8 \uC9C0\uAC11\uC744 \uB9CC\uB4E4\uC5B4\uC8FC\uC138\uC694."}},58554:()=>{},4813:()=>{},45545:()=>{},46047:()=>{},78028:()=>{},50695:()=>{},84215:()=>{},47021:()=>{},24318:()=>{},3967:()=>{},73927:()=>{},77702:()=>{}},U={};function c(o){var f=U[o];if(f!==void 0)return f.exports;var l=U[o]={id:o,loaded:!1,exports:{}};return F[o].call(l.exports,l,l.exports,c),l.loaded=!0,l.exports}c.m=F,(()=>{var o=[];c.O=(f,l,h,g)=>{if(l){g=g||0;for(var p=o.length;p>0&&o[p-1][2]>g;p--)o[p]=o[p-1];o[p]=[l,h,g];return}for(var y=Infinity,p=0;p<o.length;p++){for(var[l,h,g]=o[p],E=!0,b=0;b<l.length;b++)(g&!1||y>=g)&&Object.keys(c.O).every(Z=>c.O[Z](l[b]))?l.splice(b--,1):(E=!1,g<y&&(y=g));E&&(o.splice(p--,1),f=h())}return f}})(),(()=>{c.n=o=>{var f=o&&o.__esModule?()=>o.default:()=>o;return c.d(f,{a:f}),f}})(),(()=>{var o=Object.getPrototypeOf?l=>Object.getPrototypeOf(l):l=>l.__proto__,f;c.t=function(l,h){if(h&1&&(l=this(l)),h&8||typeof l=="object"&&l&&(h&4&&l.__esModule||h&16&&typeof l.then=="function"))return l;var g=Object.create(null);c.r(g);var p={};f=f||[null,o({}),o([]),o(o)];for(var y=h&2&&l;typeof y=="object"&&!~f.indexOf(y);y=o(y))Object.getOwnPropertyNames(y).forEach(E=>p[E]=()=>l[E]);return p.default=()=>l,c.d(g,p),g}})(),(()=>{c.d=(o,f)=>{for(var l in f)c.o(f,l)&&!c.o(o,l)&&Object.defineProperty(o,l,{enumerable:!0,get:f[l]})}})(),(()=>{c.g=function(){if(typeof globalThis=="object")return globalThis;try{return this||new Function("return this")()}catch(o){if(typeof window=="object")return window}}()})(),(()=>{c.hmd=o=>(o=Object.create(o),o.children||(o.children=[]),Object.defineProperty(o,"exports",{enumerable:!0,set:()=>{throw new Error("ES Modules may not assign module.exports or exports.*, Use ESM export syntax, instead: "+o.id)}}),o)})(),(()=>{c.o=(o,f)=>Object.prototype.hasOwnProperty.call(o,f)})(),(()=>{c.r=o=>{typeof Symbol!="undefined"&&Symbol.toStringTag&&Object.defineProperty(o,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(o,"__esModule",{value:!0})}})(),(()=>{c.nmd=o=>(o.paths=[],o.children||(o.children=[]),o)})(),(()=>{c.j=784})(),(()=>{var o={784:0};c.O.j=h=>o[h]===0;var f=(h,g)=>{var[p,y,E]=g,b,w,j=0;for(b in y)c.o(y,b)&&(c.m[b]=y[b]);for(E&&E(c),h&&h(g);j<p.length;j++)w=p[j],c.o(o,w)&&o[w]&&o[w][0](),o[p[j]]=0;c.O()},l=self.webpackChunkweb_template=self.webpackChunkweb_template||[];l.forEach(f.bind(null,0)),l.push=f.bind(null,l.push.bind(l))})();var H=c.O(void 0,[736],()=>c(74384));H=c.O(H)})();

//# sourceMappingURL=tx.e745d0180fd23bcff552.js.map