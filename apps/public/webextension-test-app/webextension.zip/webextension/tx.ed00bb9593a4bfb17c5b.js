(()=>{var me={43013:()=>{},29348:()=>{},65494:(c,E,i)=>{"use strict";var A=i(74296),y=i(86006),x=i(48521),T=i(39573),D=i(96774),_=i(71742),S=i(53169);const j=S.ZP.ul`
  list-style: none;
  padding: 0;

  li {
    height: 2.5em;

    display: flex;
    justify-content: space-between;
    align-items: center;

    &:not(:first-child) {
      border-top: 1px dashed #eeeeee;
    }

    a {
      color: inherit;
    }

    color: #000000;

    &[data-selected='false'] {
      color: #bbbbbb;

      &:hover {
        color: #555555;
      }
    }

    svg {
      font-size: 1.2em;
      transform: translateY(0.17em);
    }

    img {
      width: 1.2em;
      height: 1.2em;
      transform: translateY(0.17em) scale(1.2);
    }

    i {
      margin-right: ${({iconMarginRight:e="0.2em"})=>e};
    }

    span {
      display: inline-block;

      &:first-letter {
        text-transform: ${({firstLetterUpperCase:e=!0})=>e?"uppercase":"none"};
      }
    }

    button {
      border: none;
      outline: none;
      background-color: transparent;
      padding: 0;

      cursor: pointer;

      color: #bbbbbb;

      &:hover {
        color: #555555;
      }
    }
  }
`;var nt=i(33442),$=i(82298);function ve(){return new MnemonicKey({coinType:330})}function Or(e){if(!validateMnemonic(e))throw new Error("mnemonic key is invalid!");return new MnemonicKey({mnemonic:e,coinType:330})}function Pr(e){var t,r;return{privateKey:e.privateKey.toString("hex"),publicKey:(r=(t=e.publicKey)==null?void 0:t.toString("hex"))!=null?r:"",terraAddress:e.accAddress}}function Wr(e,t){return encrypt(JSON.stringify(e),t)}function at(e,t){return JSON.parse((0,nt.pe)(e,t))}var a=i(27378);const k=700,R=380,st=R/k;var ot=Object.defineProperty,we=Object.prototype.hasOwnProperty,Q=Object.getOwnPropertySymbols,Ee=Object.prototype.propertyIsEnumerable,xe=(e,t,r)=>t in e?ot(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r,lt=(e,t)=>{for(var r in t||(t={}))we.call(t,r)&&xe(e,r,t[r]);if(Q)for(var r of Q(t))Ee.call(t,r)&&xe(e,r,t[r]);return e},it=(e,t)=>{var r={};for(var n in e)we.call(e,n)&&t.indexOf(n)<0&&(r[n]=e[n]);if(e!=null&&Q)for(var n of Q(e))t.indexOf(n)<0&&Ee.call(e,n)&&(r[n]=e[n]);return r};function ct(e){var{variant:t,borderRadius:r,children:n}=e,l=it(e,["variant","borderRadius","children"]);return a.createElement("svg",lt({viewBox:`0 0 ${k} ${R}`},l),n)}const dt=(0,S.ZP)(ct)`
  border-radius: ${({variant:e="medium",borderRadius:t=e==="medium"?30:20})=>t}px;

  background-color: #ffffff;
  border: 3px dashed #aaaaaa;

  svg {
    color: #aaaaaa;
  }
`;var ut=Object.defineProperty,ye=Object.prototype.hasOwnProperty,q=Object.getOwnPropertySymbols,Se=Object.prototype.propertyIsEnumerable,be=(e,t,r)=>t in e?ut(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r,ft=(e,t)=>{for(var r in t||(t={}))ye.call(t,r)&&be(e,r,t[r]);if(q)for(var r of q(t))Se.call(t,r)&&be(e,r,t[r]);return e},pt=(e,t)=>{var r={};for(var n in e)ye.call(e,n)&&t.indexOf(n)<0&&(r[n]=e[n]);if(e!=null&&q)for(var n of q(e))t.indexOf(n)<0&&Se.call(e,n)&&(r[n]=e[n]);return r};function mt(e){var{variant:t="medium",borderRadius:r,textColor:n}=e,l=pt(e,["variant","borderRadius","textColor"]);return a.createElement("svg",ft({viewBox:`0 0 ${k} ${R}`},l))}const ht=(0,S.ZP)(mt)`
  box-shadow: 0 2px 6px 2px rgba(0, 0, 0, 0.43);

  border-radius: ${({variant:e="medium",borderRadius:t=e==="medium"?30:20})=>t}px;

  text {
    font-family: sans-serif;
    fill: ${({textColor:e="#ffffff"})=>e};
  }
`;var gt=i(78781);function vt({name:e,terraAddress:t,variant:r}){return r==="medium"?a.createElement(a.Fragment,null,a.createElement("text",{x:60,y:250,fontSize:23,opacity:.7},t),a.createElement("text",{x:60,y:300,fontSize:35},e)):a.createElement(a.Fragment,null,a.createElement("text",{x:60,y:220,fontSize:40,opacity:.7},(0,gt.truncate)(t)),a.createElement("text",{x:60,y:300,fontSize:60},e))}var wt=Object.defineProperty,Oe=Object.prototype.hasOwnProperty,ee=Object.getOwnPropertySymbols,Pe=Object.prototype.propertyIsEnumerable,We=(e,t,r)=>t in e?wt(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r,Et=(e,t)=>{for(var r in t||(t={}))Oe.call(t,r)&&We(e,r,t[r]);if(ee)for(var r of ee(t))Pe.call(t,r)&&We(e,r,t[r]);return e},xt=(e,t)=>{var r={};for(var n in e)Oe.call(e,n)&&t.indexOf(n)<0&&(r[n]=e[n]);if(e!=null&&ee)for(var n of ee(e))t.indexOf(n)<0&&Pe.call(e,n)&&(r[n]=e[n]);return r};function yt(e){var{design:t,name:r,terraAddress:n,variant:l="medium",ref:s}=e,f=xt(e,["design","name","terraAddress","variant","ref"]);const o=(0,a.useMemo)(()=>(0,a.isValidElement)(t)?t:t==="anchor"?a.createElement("image",{xlinkHref:"/assets/wallet/Anchor.svg",width:k,height:R}):t==="terra"?a.createElement("image",{xlinkHref:"/assets/wallet/Terra.svg",width:k,height:R}):typeof t=="string"?a.createElement("rect",{fill:t,width:k+20,height:R+20}):a.createElement("image",{xlinkHref:"/assets/wallet/Terra.svg",width:k,height:R}),[t]);return a.createElement(ht,Et({variant:l},f),o,a.createElement(vt,{name:r,terraAddress:n,variant:l}))}var St=i(81347),bt=Object.defineProperty,_e=Object.prototype.hasOwnProperty,te=Object.getOwnPropertySymbols,Ce=Object.prototype.propertyIsEnumerable,Ae=(e,t,r)=>t in e?bt(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r,Ot=(e,t)=>{for(var r in t||(t={}))_e.call(t,r)&&Ae(e,r,t[r]);if(te)for(var r of te(t))Ce.call(t,r)&&Ae(e,r,t[r]);return e},Pt=(e,t)=>{var r={};for(var n in e)_e.call(e,n)&&t.indexOf(n)<0&&(r[n]=e[n]);if(e!=null&&te)for(var n of te(e))t.indexOf(n)<0&&Ce.call(e,n)&&(r[n]=e[n]);return r};const K=20;function Wt(e){var{cardWidth:t,children:r,selectedIndex:n,onSelect:l,onCreate:s}=e,f=Pt(e,["cardWidth","children","selectedIndex","onSelect","onCreate"]);const o=(0,a.useMemo)(()=>{if(!r)return null;const d=Array.isArray(r)?r:[r];return d.length===0?null:d.map((p,g)=>{const m=t*(g-n),u=1-Math.abs((g-n)*.2),w=1-Math.abs((g-n)*.4);return a.createElement("li",{key:"card"+g,onClick:()=>n!==g&&l(g),style:{transform:`translate(${m-K}px, ${-K}px) scale(${u})`,opacity:w,filter:Math.abs(g-n)===1?"blur(2px)":void 0,cursor:n!==g?"pointer":void 0}},p)})},[t,r,l,n]);return a.createElement("ul",Ot({},f),o||(typeof s=="function"?a.createElement("li",{onClick:s,style:{cursor:"pointer"}},a.createElement(dt,{style:{transform:`translate(${-K}px, ${-K}px)`}},a.createElement("g",{transform:"translate(350 190)"},a.createElement("g",{transform:"translate(-100 -100)"},a.createElement(St.Z,{width:"200",height:"200"}))))):null))}const _r=(0,S.ZP)(Wt)`
  list-style: none;
  padding: 0;
  margin: 20px 0;

  position: relative;

  min-width: ${({cardWidth:e})=>e}px;
  max-width: ${({cardWidth:e})=>e}px;
  height: ${({cardWidth:e})=>Math.ceil(e*st)}px;

  > li {
    position: absolute;
    left: 0;
    top: 0;
    padding: ${K}px;

    user-select: none;

    > svg {
      width: ${({cardWidth:e})=>e}px;
    }

    will-change: transform, opacity, filter;
    transition: transform 0.3s ease-in-out, opacity 0.3s;
  }
`;var Cr=i(23630);class _t extends Error{constructor(){super("User Denied");this.toString=()=>`[${this.name}]`,this.toJSON=()=>({name:this.name}),this.name="WebExtensionUserDenied"}}class Te extends Error{constructor(t){super(t);this.toString=()=>`[${this.name} message="${this.message}"]`,this.toJSON=()=>({name:this.name,message:this.message}),this.name="WebExtensionCreateTxFailed"}}class Ie extends Error{constructor(t,r,n){super(r);this.txhash=t,this.raw_message=n,this.toString=()=>`[${this.name} txhash="${this.txhash}" message="${this.message}"]
${JSON.stringify(this.raw_message,null,2)}`,this.toJSON=()=>({name:this.name,txhash:this.txhash,message:this.message,raw_message:this.raw_message}),this.name="WebExtensionTxFailed"}}class Ne extends Error{constructor(t){super(t);this.toString=()=>`[${this.name} message="${this.message}"]`,this.toJSON=()=>({name:this.name,message:this.message}),this.name="WebExtensionTxUnspecifiedError"}}function Ar(e){switch(e.name){case"WebExtensionUserDenied":return new _t;case"WebExtensionCreateTxFailed":return new Te(e.message);case"WebExtensionTxFailed":return new Ie(e.txhash,e.message,e.raw_message);default:return new Ne("message"in e?e.message:String(e))}}var J;(function(e){e.REFETCH_STATES="refetch_states",e.EXECUTE_TX="execute_tx",e.REQUEST_APPROVAL="request_approval"})(J||(J={}));var re;(function(e){e.STATES_UPDATED="states_updated",e.TX_RESPONSE="tx_response"})(re||(re={}));function Tr(e){if(!e||typeof e!="object"||!("type"in(e!=null?e:{})))return!1;const t=e;switch(t.type){case J.REFETCH_STATES:return!0;case J.EXECUTE_TX:return typeof t.id=="number"&&!!t.payload;case J.REQUEST_APPROVAL:return!0;case re.STATES_UPDATED:return!!t.payload;case re.TX_RESPONSE:return typeof t.id=="number"&&!!t.payload;default:return!1}}var Le;(function(e){e.NEW_WALLET="new_wallet",e.NETWORK_CHANGED="network_changed",e.WALLET_CHANGED="wallet_changed",e.ALL_WALLETS_REMOVED="all_wallet_removed"})(Le||(Le={}));var Ir=i(43013),Nr=i(29348),Me;(function(e){e.INITIALIZING="initializing",e.NO_AVAILABLE="no_available",e.READY="ready"})(Me||(Me={}));var Ct=i(71515),At=i(30816).Buffer,Tt=Object.defineProperty,It=Object.prototype.hasOwnProperty,De=Object.getOwnPropertySymbols,Nt=Object.prototype.propertyIsEnumerable,ke=(e,t,r)=>t in e?Tt(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r,Re=(e,t)=>{for(var r in t||(t={}))It.call(t,r)&&ke(e,r,t[r]);if(De)for(var r of De(t))Nt.call(t,r)&&ke(e,r,t[r]);return e},N;(function(e){e.PROGRESS="PROGRESS",e.SUCCEED="SUCCEED",e.FAIL="FAIL",e.DENIED="DENIED"})(N||(N={}));function Lr(e){var t,r,n;return{msgs:e.msgs.map(l=>l.toJSON()),fee:(t=e.fee)==null?void 0:t.toJSON(),memo:e.memo,gasPrices:(r=e.gasPrices)==null?void 0:r.toString(),gasAdjustment:(n=e.gasAdjustment)==null?void 0:n.toString(),account_number:e.account_number,sequence:e.sequence,feeDenoms:e.feeDenoms}}function Ue(e){return Re(Re({},e),{msgs:e.msgs.map(t=>$.Msg.fromData(JSON.parse(t))),fee:e.fee?$.StdFee.fromData(JSON.parse(e.fee)):void 0})}function Lt(e,t,r){return new Ct.y(n=>{const l=new $.LCDClient({chainID:t.chainID,URL:t.lcd,gasPrices:r.gasPrices,gasAdjustment:r.gasAdjustment}),{privateKey:s}=e,f=new $.RawKey(At.from(s,"hex"));l.wallet(f).createAndSignTx(Ue(r)).then(o=>l.tx.broadcastSync(o)).then(o=>{(0,$.isTxError)(o)?(n.next({status:N.FAIL,error:o.txhash?new Ie(o.txhash,o.raw_log,o.raw_log):new Te(o.raw_log)}),n.complete()):(n.next({status:N.SUCCEED,payload:{txhash:o.txhash,height:o.height,raw_log:o.raw_log}}),n.complete())}).catch(o=>{n.next({status:N.FAIL,error:new Ne("message"in o?o.message:String(o))}),n.complete()})})}var Mt=Object.prototype.hasOwnProperty,Fe=Object.getOwnPropertySymbols,Dt=Object.prototype.propertyIsEnumerable,kt=(e,t)=>{var r={};for(var n in e)Mt.call(e,n)&&t.indexOf(n)<0&&(r[n]=e[n]);if(e!=null&&Fe)for(var n of Fe(e))t.indexOf(n)<0&&Dt.call(e,n)&&(r[n]=e[n]);return r};function Rt(e){return e.type===WebExtensionStatusType.NO_AVAILABLE&&e.isApproved===!1}class Mr{constructor(t){if(this.hostWindow=t,this.refetchStates=()=>{const s={type:FromWebToContentScriptMessage.REFETCH_STATES};this.hostWindow.postMessage(s,"*")},this.requestApproval=()=>{const s=this._status.getValue();if(Rt(s)){const f={type:FromWebToContentScriptMessage.REQUEST_APPROVAL};this.hostWindow.postMessage(f,"*")}else console.warn(`requestApproval() is ignored. do not call at this status is "${JSON.stringify(s)}"`)},this.status=()=>this._status.asObservable(),this.getLastStatus=()=>this._status.getValue(),this.post=({terraAddress:s,network:f,tx:o})=>new Observable(d=>{d.next({status:WebExtensionTxStatus.PROGRESS});const p=Date.now(),g={type:FromWebToContentScriptMessage.EXECUTE_TX,id:p,terraAddress:s,network:f,payload:serializeTx(o)};this.hostWindow.postMessage(g,"*");const m=u=>{if(!(!isWebExtensionMessage(u.data)||u.data.type!==FromContentScriptToWebMessage.TX_RESPONSE||u.data.id!==p)){if(u.data.payload.status===WebExtensionTxStatus.PROGRESS)d.next(u.data.payload);else if(u.data.payload.status===WebExtensionTxStatus.DENIED||u.data.payload.status===WebExtensionTxStatus.FAIL||u.data.payload.status===WebExtensionTxStatus.SUCCEED){switch(u.data.payload.status){case WebExtensionTxStatus.DENIED:d.error(new WebExtensionUserDenied);break;case WebExtensionTxStatus.FAIL:d.error(u.data.payload.error instanceof Error?u.data.payload.error:createTxErrorFromJson(u.data.payload.error));break;case WebExtensionTxStatus.SUCCEED:d.next(u.data.payload),d.complete();break}this.hostWindow.removeEventListener("message",m)}}};return this.hostWindow.addEventListener("message",m),()=>{this.hostWindow.removeEventListener("message",m)}}),this.states=()=>this._states.asObservable(),this.getLastStates=()=>this._states.getValue(),this.destroy=()=>{this.hostWindow.removeEventListener("message",this.onMessage)},this.onMessage=s=>{if(!!isWebExtensionMessage(s.data))switch(s.data.type){case FromContentScriptToWebMessage.STATES_UPDATED:const f=this._status.getValue(),o=s.data.payload,{isApproved:d}=o,p=kt(o,["isApproved"]);d?f.type!==WebExtensionStatusType.READY&&this._status.next({type:WebExtensionStatusType.READY}):f.type!==WebExtensionStatusType.NO_AVAILABLE&&this._status.next({type:WebExtensionStatusType.NO_AVAILABLE,isSupportBrowser:!0,isInstalled:!0,isApproved:!1}),this._states.next(p);break}},this._status=new BehaviorSubject({type:WebExtensionStatusType.INITIALIZING}),this._states=new BehaviorSubject(null),!document.querySelector('head > meta[name="terra-webextension"]'))return;const n=getParser(navigator.userAgent);if(!n.satisfies({desktop:{chrome:">70",edge:">80",firefox:">80",safari:">=14"}})){this._status.next({type:WebExtensionStatusType.NO_AVAILABLE,isSupportBrowser:!1});return}t.addEventListener("message",this.onMessage),this.refetchStates(),setTimeout(()=>{if(this._status.getValue().type===WebExtensionStatusType.INITIALIZING){const s=n.getBrowserName(!0);let f;switch(s){case"chrome":case"microsoft edge":f="https://google.com/chrome";break;case"firefox":f="https://google.com/firefox";break;case"safari":f="https://google.com/safari";break;default:f="https://google.com/chrome";break}this._status.next({type:WebExtensionStatusType.NO_AVAILABLE,isSupportBrowser:!0,isInstalled:!1,installLink:f})}},2e3)}}var Dr=i(66471),ie=i(1532);function kr(e){return new Observable(t=>{if(browser.runtime.getURL("").startsWith("safari-web-extension://")){let r=null;const n=interval(1e3).subscribe(()=>{browser.storage.local.get(e).then(l=>{const s=l[e];r!==null&&deepEqual(r,s)||(r=s,t.next(s))})});return()=>{n.unsubscribe()}}})}var Ut=Object.defineProperty,je=Object.prototype.hasOwnProperty,ne=Object.getOwnPropertySymbols,$e=Object.prototype.propertyIsEnumerable,Be=(e,t,r)=>t in e?Ut(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r,Ft=(e,t)=>{for(var r in t||(t={}))je.call(t,r)&&Be(e,r,t[r]);if(ne)for(var r of ne(t))$e.call(t,r)&&Be(e,r,t[r]);return e},jt=(e,t)=>{var r={};for(var n in e)je.call(e,n)&&t.indexOf(n)<0&&(r[n]=e[n]);if(e!=null&&ne)for(var n of ne(e))t.indexOf(n)<0&&$e.call(e,n)&&(r[n]=e[n]);return r},U=(e,t,r)=>new Promise((n,l)=>{var s=d=>{try{o(r.next(d))}catch(p){l(p)}},f=d=>{try{o(r.throw(d))}catch(p){l(p)}},o=d=>d.done?n(d.value):Promise.resolve(d.value).then(s,f);o((r=r.apply(e,t)).next())});const B="terra_network_storage_v1";function H(){return U(this,null,function*(){var e;return(e=(yield browser.storage.local.get(B))[B])!=null?e:{networks:[],selectedNetwork:void 0}})}function ae(e){return U(this,null,function*(){yield browser.storage.local.set({[B]:e})})}function Rr(e){return U(this,null,function*(){const{networks:t}=yield H();return t.find(r=>r.name===e)})}function Ur(e){return U(this,null,function*(){const{networks:t}=yield H(),r=[...t,e];yield ae({networks:r,selectedNetwork:e})})}function Fr(e){return U(this,null,function*(){const{networks:t,selectedNetwork:r}=yield H(),n=t.filter(({name:s})=>e.name!==s),l=e.name===(r==null?void 0:r.name)&&n.length>0?n[0]:r;yield ae({networks:n,selectedNetwork:l})})}function jr(e,t){return U(this,null,function*(){const{networks:r,selectedNetwork:n}=yield H(),l=r.findIndex(o=>o.name===e);if(l===-1)return;const s=[...r];s.splice(l,1,t);const f=(n==null?void 0:n.name)===e?t:n;yield ae({networks:s,selectedNetwork:f})})}function $r(){return new Observable(e=>{function t(n,l){if(l==="local"&&n[B]){const{newValue:s}=n[B];e.next(s!=null?s:{networks:[],selectedNetwork:void 0})}}browser.storage.onChanged.addListener(t);const r=safariWebExtensionStorageChangeListener(B).subscribe(n=>{e.next(n!=null?n:{networks:[],selectedNetwork:void 0})});return H().then(n=>{e.next(n)}),()=>{browser.storage.onChanged.removeListener(t),r.unsubscribe()}})}function Br(e){return U(this,null,function*(){const t=yield H(),{selectedNetwork:r}=t,n=jt(t,["selectedNetwork"]);yield ae(Ft({selectedNetwork:e},n))})}var $t=Object.defineProperty,He=Object.prototype.hasOwnProperty,se=Object.getOwnPropertySymbols,Ve=Object.prototype.propertyIsEnumerable,ze=(e,t,r)=>t in e?$t(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r,O=(e,t)=>{for(var r in t||(t={}))He.call(t,r)&&ze(e,r,t[r]);if(se)for(var r of se(t))Ve.call(t,r)&&ze(e,r,t[r]);return e},X=(e,t)=>{var r={};for(var n in e)He.call(e,n)&&t.indexOf(n)<0&&(r[n]=e[n]);if(e!=null&&se)for(var n of se(e))t.indexOf(n)<0&&Ve.call(e,n)&&(r[n]=e[n]);return r},I=(e,t,r)=>new Promise((n,l)=>{var s=d=>{try{o(r.next(d))}catch(p){l(p)}},f=d=>{try{o(r.throw(d))}catch(p){l(p)}},o=d=>d.done?n(d.value):Promise.resolve(d.value).then(s,f);o((r=r.apply(e,t)).next())});const V="terra_wallet_storage_v1-alpha.3";function L(){return I(this,null,function*(){var e;return(e=(yield ie.browser.storage.local.get(V))[V])!=null?e:{wallets:[],approvedHostnames:[]}})}function z(e){return I(this,null,function*(){yield browser.storage.local.set({[V]:e})})}function Bt(e){return I(this,null,function*(){const{wallets:t}=yield L();return t.find(r=>r.terraAddress===e)})}function Hr(e){return I(this,null,function*(){const t=yield L(),{wallets:r,focusedWalletAddress:n}=t,l=X(t,["wallets","focusedWalletAddress"]),s=O(O({},l),{wallets:[...r,e],focusedWalletAddress:e.terraAddress});yield z(s)})}function Vr(e){return I(this,null,function*(){var t;const r=yield L(),{wallets:n,focusedWalletAddress:l}=r,s=X(r,["wallets","focusedWalletAddress"]),f=n.findIndex(g=>g.terraAddress===e.terraAddress);if(f===-1)return;const o=[...n];o.splice(f,1);const d=o.length>0?(t=o.find(g=>g.terraAddress===l))!=null?t:o[Math.max(0,Math.min(o.length-1,f-1))]:void 0,p=O(O({},s),{wallets:o,focusedWalletAddress:d==null?void 0:d.terraAddress});yield z(p)})}function zr(e,t){return I(this,null,function*(){const r=yield L(),{wallets:n}=r,l=X(r,["wallets"]),s=n.findIndex(o=>o.terraAddress===e);if(s===-1)return;const f=[...n];f.splice(s,1,t),yield z(O(O({},l),{wallets:f}))})}function Zr(e){return I(this,null,function*(){const t=yield L();yield z(O(O({},t),{focusedWalletAddress:e}))})}function Kr(...e){return I(this,null,function*(){const t=yield L(),{approvedHostnames:r}=t,n=X(t,["approvedHostnames"]),l=new Set([...r,...e]);yield z(O(O({},n),{approvedHostnames:Array.from(l)}))})}function Jr(...e){return I(this,null,function*(){const t=yield L(),{approvedHostnames:r}=t,n=X(t,["approvedHostnames"]),l=new Set(e),s=r.filter(f=>!l.has(f));yield z(O(O({},n),{approvedHostnames:s}))})}function Xr(){return new Observable(e=>{function t(n,l){if(l==="local"&&n[V]){const{newValue:s}=n[V];e.next(s!=null?s:{wallets:[],approvedHostnames:[]})}}browser.storage.onChanged.addListener(t);const r=safariWebExtensionStorageChangeListener(V).subscribe(n=>{e.next(n!=null?n:{wallets:[],approvedHostnames:[]})});return L().then(n=>{e.next(n)}),()=>{browser.storage.onChanged.removeListener(t),r.unsubscribe()}})}var Gr=i(65209),Ht=Object.defineProperty,Ze=Object.prototype.hasOwnProperty,oe=Object.getOwnPropertySymbols,Ke=Object.prototype.propertyIsEnumerable,Je=(e,t,r)=>t in e?Ht(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r,M=(e,t)=>{for(var r in t||(t={}))Ze.call(t,r)&&Je(e,r,t[r]);if(oe)for(var r of oe(t))Ke.call(t,r)&&Je(e,r,t[r]);return e},Vt=(e,t)=>{var r={};for(var n in e)Ze.call(e,n)&&t.indexOf(n)<0&&(r[n]=e[n]);if(e!=null&&oe)for(var n of oe(e))t.indexOf(n)<0&&Ke.call(e,n)&&(r[n]=e[n]);return r},zt=(e,t,r)=>new Promise((n,l)=>{var s=d=>{try{o(r.next(d))}catch(p){l(p)}},f=d=>{try{o(r.throw(d))}catch(p){l(p)}},o=d=>d.done?n(d.value):Promise.resolve(d.value).then(s,f);o((r=r.apply(e,t)).next())});function Yr({startTx:e,startConnect:t,defaultNetworks:r}){var n,l;const s=document.querySelector('head > meta[name="terra-webextension"]');if(!s)return;const f=new Set((l=(n=s.getAttribute("legacy"))==null?void 0:n.split(","))!=null?l:[]);if(s.setAttribute("connected","true"),f.has("terra.js")){const m=document.createElement("script");m.innerText="window.isTerraExtensionAvailable = true;";const u=document.querySelector("head");u==null||u.appendChild(m)}const o=new BehaviorSubject(Date.now()),d=observeWalletStorage().pipe(map(({wallets:m,focusedWalletAddress:u,approvedHostnames:w})=>{const P=window.location.hostname;return w.includes(P)?{wallets:m.map(W=>{var{encryptedWallet:h}=W,C=Vt(W,["encryptedWallet"]);return C}),focusedWalletAddress:u,isApproved:!0}:{wallets:[],focusedWalletAddress:void 0,isApproved:!1}})),p=observeNetworkStorage().pipe(map(({selectedNetwork:m})=>m!=null?m:r[0])),g=combineLatest([o,d,p]).pipe(map(([m,{wallets:u,focusedWalletAddress:w,isApproved:P},W])=>({wallets:u,network:W,focusedWalletAddress:w,isApproved:P})));if(f.has("terra.js")){let m=function(h){P?h(P):W.add(h)},u=function({wallets:h,focusedWalletAddress:C}){var Z;if(h.length===0)throw new Error("the wallets should have at least one more wallet!!!");const b=C&&(Z=h.findIndex(F=>F.terraAddress===C))!=null?Z:0;return h[b]};const w=new LocalMessageDuplexStream({name:"station:content",target:"station:inpage"});let P=null,W=new Set;g.subscribe(h=>{if(P=h,W.size>0){for(const C of W)C(h);W.clear()}}),w.on("data",h=>zt(this,null,function*(){switch(h.type){case"info":m(({network:b})=>{w.write({name:"onInfo",id:h.id,payload:{chainID:b.chainID,name:b.name,lcd:b.lcd}})});break;case"connect":let C=function(b){const F=u(b);w.write({name:"onConnect",id:h.id,payload:{address:F.terraAddress}})},Z=function(){w.write({name:"onConnect",id:h.id,payload:{}})};m(b=>{b.wallets.length>0?C(b):t(h.id.toString(),window.location.hostname).then(F=>{F?m(Y=>{C(Y)}):Z()})});break;case"post":m(b=>{if(b.wallets.length>0){const F=u(b);e(h.id.toString(),F.terraAddress,b.network,h).subscribe(Y=>{switch(Y.status){case WebExtensionTxStatus.DENIED:w.write({name:"onPost",id:h.id,payload:M(M({},h),{success:!1,error:{code:1}})});break;case WebExtensionTxStatus.FAIL:w.write({name:"onPost",id:h.id,payload:M(M({},h),{success:!1,error:{code:3,message:String(Y.error)}})});break;case WebExtensionTxStatus.SUCCEED:w.write({name:"onPost",id:h.id,payload:M(M({},h),{success:!0,result:Y.payload})});break}})}else w.write({name:"onPost",id:h.id,payload:M(M({},h),{success:!1,error:{code:3,message:"no wallets"}})})});break;default:console.log("initContentScriptAndWebappConnection.ts..()",h);break}}))}else{let m=null;window.addEventListener("message",u=>{if(!!isWebExtensionMessage(u.data))switch(u.data.type){case FromWebToContentScriptMessage.REFETCH_STATES:o.next(Date.now());break;case FromWebToContentScriptMessage.REQUEST_APPROVAL:if((m==null?void 0:m.isApproved)===!0){console.warn(`${window.location.hostname} is already approved!`);break}t(Date.now().toString(),window.location.hostname).then(()=>{o.next(Date.now())});break;case FromWebToContentScriptMessage.EXECUTE_TX:e(u.data.id.toString(),u.data.terraAddress,u.data.network,u.data.payload).subscribe(w=>{const P={type:FromContentScriptToWebMessage.TX_RESPONSE,id:u.data.id,payload:w};window.postMessage(P,"*")});break}},!1),g.subscribe(u=>{m=u;const w={type:FromContentScriptToWebMessage.STATES_UPDATED,payload:u};window.postMessage(w,"*")})}}var ce;(function(e){e.SAME_NAME_EXISTS="SAME_NAME_EXISTS"})(ce||(ce={}));function Qr(e){const[t,r]=useState([]);return useEffect(()=>{readWalletStorage().then(({wallets:n})=>r(n))},[]),useMemo(()=>e.length===0?null:t.length>0&&t.some(n=>n.name===e)?ce.SAME_NAME_EXISTS:null,[t,e])}var de;(function(e){e.TOO_SHORT="TOO_SHORT"})(de||(de={}));function qr(e){return useMemo(()=>e.length===0?null:e.length<10?de.TOO_SHORT:null,[e.length])}var ue;(function(e){e.INVALID_MNEMONIC_KEY="INVALID_MNEMONIC_KEY"})(ue||(ue={}));function en(e){return useMemo(()=>e.length===0||validateMnemonic(e)?null:ue.INVALID_MNEMONIC_KEY,[e])}var fe;(function(e){e.SAME_NAME_EXISTS="SAME_NAME_EXISTS"})(fe||(fe={}));function tn(e,t){const[r,n]=useState(t);return useEffect(()=>{readNetworkStorage().then(({networks:l})=>n([...t,...l]))},[t]),useMemo(()=>e.length===0?null:r.length>0&&r.some(l=>l.name===e)?fe.SAME_NAME_EXISTS:null,[r,e])}var pe;(function(e){e.INVALID_URL="INVALID_URL"})(pe||(pe={}));function rn(e){return useMemo(()=>e.startsWith("https://")||e.startsWith("http://")?null:pe.INVALID_URL,[e])}const Zt=S.vJ`
  html,
  body {
    margin: 0;
    background-color: ${({backgroundColor:e})=>e!=null?e:"#0c3694"}
  }
  
  
  html {
    font-family: 'Segoe UI', 'Roboto', 'Oxygen',
    'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue',
    sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    font-size: 16px;
    word-spacing: 1px;
    -ms-text-size-adjust: 100%;
    -webkit-text-size-adjust: 100%;
    box-sizing: border-box;
  }
  
  *,
  *::before,
  *::after {
    box-sizing: border-box;
    margin: 0;
    font-family: 'Segoe UI', 'Roboto', 'Oxygen',
    'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue',
    sans-serif;
  }
  
  ::-webkit-scrollbar {
    display: none;
  }
  
  input::-webkit-outer-spin-button,
  input::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
  }
`;var Kt=i(31542),Jt=i(65785);class Xt extends a.Component{constructor(t){super(t);this.state={error:null}}static getDerivedStateFromError(t){return{error:t}}componentDidCatch(t,r){this.setState({error:t}),console.error(r)}render(){return this.state.error?a.createElement(Gt,null,this.state.error.toString()):this.props.children}}const Gt=S.ZP.pre`
  width: 100%;
  max-height: 500px;
  overflow-y: auto;
  font-size: 12px;
`;var Yt=i(9031),Qt=i(9969);function qt({className:e,tx:t}){return a.createElement("ul",{className:e},t==null?void 0:t.msgs.map((r,n)=>a.createElement(er,{key:"msg"+n,msg:r})))}function er({msg:e}){const[t,r]=(0,a.useState)(!1);return e instanceof $.MsgExecuteContract?a.createElement("li",null,a.createElement("h3",{onClick:()=>r(n=>!n)},a.createElement("span",null,"MsgExecuteContract"),t?a.createElement(Yt.Z,null):a.createElement(Qt.Z,null)),t&&a.createElement("ul",null,a.createElement("li",null,a.createElement("h4",null,"Sender"),a.createElement("p",null,e.sender)),a.createElement("li",null,a.createElement("h4",null,"Contract"),a.createElement("p",null,e.contract)),a.createElement("li",null,a.createElement("h4",null,"execute_msg"),a.createElement("pre",null,JSON.stringify(e.execute_msg,null,2))),a.createElement("li",null,a.createElement("h4",null,"Coins"),a.createElement("p",null,e.coins.toJSON())))):null}const tr=(0,S.ZP)(qt)`
  list-style: none;
  padding: 0;

  margin: 20px 0;

  > li {
    &:not(:first-child) {
      margin-top: 10px;
    }

    border-radius: 8px;
    border: 1px solid #81a2cb;
    background-color: #f7fbff;

    padding: 10px;

    h3 {
      font-size: 1em;

      user-select: none;
      cursor: pointer;

      display: flex;
      justify-content: space-between;
      align-items: center;

      svg {
        font-size: 1.2em;
      }
    }

    ul {
      margin-top: 15px;

      list-style: none;
      padding: 0;

      li {
        h4 {
          margin-bottom: 5px;
        }

        p,
        pre {
          font-size: 1em;
        }

        &:not(:first-child) {
          margin-top: 10px;
        }
      }
    }
  }
`;var Xe=i(56490),rr=i(78693),Ge=i.n(rr),nr=i(80082),ar=i.n(nr),sr=Object.defineProperty,or=Object.prototype.hasOwnProperty,Ye=Object.getOwnPropertySymbols,lr=Object.prototype.propertyIsEnumerable,Qe=(e,t,r)=>t in e?sr(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r,qe=(e,t)=>{for(var r in t||(t={}))or.call(t,r)&&Qe(e,r,t[r]);if(Ye)for(var r of Ye(t))lr.call(t,r)&&Qe(e,r,t[r]);return e};const ir=["en-US","ko-KR"],cr=Ge(),dr=qe(qe({},Ge()),ar());function nn(e){switch(e){case"en":case"ko":return!0}return!1}const le=(0,a.createContext)();function ur({children:e}){const t=(0,a.useMemo)(()=>(0,Xe.getBrowserLocale)({fallbackLanguageCodes:["en-US"]}),[]),{locale:r,updateLocale:n}=(0,Xe.useLocale)(t);return a.createElement(le.Provider,{value:{locale:r,locales:ir,updateLocale:n}},e)}function an(){return useContext(le)}function fr(){const{locale:e}=(0,a.useContext)(le);return{locale:e.substr(0,2),messages:e==="ko-KR"?dr:cr}}const sn=le.Consumer;var pr=i(47290),mr=i(45530);function hr({children:e,injectFirst:t=!0,theme:r}){return a.createElement(pr.ZP,{injectFirst:t},a.createElement(S.f6,{theme:r},a.createElement(mr.Z,{theme:r},e)))}const on=[{name:"mainnet",chainID:"columbus-4",lcd:"https://lcd.terra.dev"},{name:"testnet",chainID:"tequila-0004",lcd:"https://tequila-lcd.terra.dev"}],et="tx-",ln="content-",cn=e=>/^tx-[0-9]+$/.test(e),dn=e=>/^content-[0-9]+$/.test(e),un=e=>e.substr(3),fn=e=>e.substr(8),pn=400,mn=50,hn=550,gn=20,vn=null;var gr=Object.defineProperty,vr=Object.prototype.hasOwnProperty,tt=Object.getOwnPropertySymbols,wr=Object.prototype.propertyIsEnumerable,rt=(e,t,r)=>t in e?gr(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r,G=(e,t)=>{for(var r in t||(t={}))vr.call(t,r)&&rt(e,r,t[r]);if(tt)for(var r of tt(t))wr.call(t,r)&&rt(e,r,t[r]);return e},Er=(e,t,r)=>new Promise((n,l)=>{var s=d=>{try{o(r.next(d))}catch(p){l(p)}},f=d=>{try{o(r.throw(d))}catch(p){l(p)}},o=d=>d.done?n(d.value):Promise.resolve(d.value).then(s,f);o((r=r.apply(e,t)).next())});function xr({className:e}){const t=(0,a.useMemo)(()=>{const p=window.location.search,g=new URLSearchParams(p),m=g.get("id"),u=g.get("terraAddress"),w=g.get("tx"),P=g.get("network"),W=g.get("hostname"),h=g.get("timestamp");if(!m||!u||!w||!P||!W||!h)throw new Error("Can't find Transaction!");const C=JSON.parse(atob(w)),Z=JSON.parse(atob(P));return{id:m,terraAddress:u,network:Z,serializedTx:C,hostname:W,timestamp:new Date(parseInt(h))}},[]),r=(0,a.useMemo)(()=>(t==null?void 0:t.serializedTx)?Ue(t==null?void 0:t.serializedTx):void 0,[t==null?void 0:t.serializedTx]),[n,l]=(0,a.useState)(""),[s,f]=(0,a.useState)(void 0);(0,a.useEffect)(()=>{!t||Bt(t.terraAddress).then(p=>f(p))},[t]);const o=(0,a.useCallback)(p=>Er(this,null,function*(){const g=at(p.encryptedWallet.encryptedWallet,p.password),m=ie.browser.runtime.connect(void 0,{name:et+p.id});Lt(g,p.network,p.serializedTx).subscribe(u=>{u.status===N.FAIL?m.postMessage(G(G({},u),{error:u.error.toJSON()})):m.postMessage(u)},u=>{m.postMessage({status:N.FAIL,error:u})},()=>{m.disconnect()})}),[]),d=(0,a.useCallback)(p=>{const g=ie.browser.runtime.connect(void 0,{name:et+p.id});g.postMessage({status:N.DENIED}),g.disconnect()},[]);return s?a.createElement("section",{className:e},a.createElement("header",null,a.createElement(yt,{className:"wallet-card",name:s.name,terraAddress:s.terraAddress,design:s.design})),a.createElement(j,{className:"wallets-actions",iconMarginRight:"0.6em",firstLetterUpperCase:!1},a.createElement("li",null,a.createElement("div",null,a.createElement("i",null,a.createElement(T.Z,null)),a.createElement("span",null,"NETWORK")),a.createElement("span",null,t.network.name," (",t.network.chainID,")")),a.createElement("li",null,a.createElement("div",null,a.createElement("i",null,a.createElement(D.Z,null)),a.createElement("span",null,"ORIGIN")),a.createElement("span",null,t.hostname)),a.createElement("li",null,a.createElement("div",null,a.createElement("i",null,a.createElement(_.Z,null)),a.createElement("span",null,"TIMESTAMP")),a.createElement("span",null,t.timestamp.toLocaleString()))),a.createElement(tr,{tx:r,className:"tx"}),a.createElement("section",{className:"form"},a.createElement(A.Z,{variant:"outlined",type:"password",size:"small",fullWidth:!0,label:"WALLET PASSWORD",InputLabelProps:{shrink:!0},value:n,onChange:({target:p})=>l(p.value)})),a.createElement("footer",null,a.createElement(y.Z,{variant:"contained",color:"secondary",onClick:()=>d(G({},t))},"Deny"),a.createElement(y.Z,{variant:"contained",color:"primary",disabled:n.length===0,onClick:()=>o(G(G({},t),{password:n,encryptedWallet:s}))},"Submit")),a.createElement(Zt,{backgroundColor:"#ffffff"})):a.createElement("div",{className:e})}const yr=(0,S.ZP)(xr)`
  max-width: 100vw;

  padding: 20px;

  font-size: 13px;

  header {
    display: flex;
    justify-content: center;

    .wallet-card {
      width: 276px;
    }

    margin-bottom: 30px;
  }

  .tx {
    margin: 30px 0;
  }

  .form {
    margin: 30px 0;
  }

  footer {
    display: flex;

    > * {
      flex: 1;

      &:not(:first-child) {
        margin-left: 10px;
      }
    }
  }
`,Sr=(0,x.Z)();function br(){const{locale:e,messages:t}=fr();return a.createElement(Jt.Z,{locale:e,messages:t},a.createElement(hr,{theme:Sr},a.createElement(yr,null)))}(0,Kt.render)(a.createElement(Xt,null,a.createElement(ur,null,a.createElement(br,null))),document.querySelector("#app"))},78693:c=>{c.exports={"wallet.change-password":"Change password","wallet.delete":"Delete wallet","wallet.recover":"Recover existing wallet","wallet.new":"New wallet","wallet.empty":"Please add a new wallet","locale.en-US":"English","locale.ko-KR":"Korean"}},80082:c=>{c.exports={"wallet.change-password":"\uBE44\uBC00\uBC88\uD638 \uBCC0\uACBD","wallet.delete":"\uC9C0\uAC11 \uC0AD\uC81C","wallet.recover":"\uAE30\uC874 \uC9C0\uAC11 \uBCF5\uC6D0\uD558\uAE30","wallet.new":"\uC0C8 \uC9C0\uAC11","wallet.empty":"\uC9C0\uAC11\uC774 \uC5C6\uC2B5\uB2C8\uB2E4. \uC0C8 \uC9C0\uAC11\uC744 \uB9CC\uB4E4\uC5B4\uC8FC\uC138\uC694."}},58554:()=>{},4813:()=>{},45545:()=>{},46047:()=>{},78028:()=>{},50695:()=>{},84215:()=>{},47021:()=>{},24318:()=>{},3967:()=>{},50471:()=>{},71632:()=>{},73927:()=>{},77702:()=>{}},he={};function v(c){var E=he[c];if(E!==void 0)return E.exports;var i=he[c]={id:c,loaded:!1,exports:{}};return me[c].call(i.exports,i,i.exports,v),i.loaded=!0,i.exports}v.m=me,(()=>{var c=[];v.O=(E,i,A,y)=>{if(i){y=y||0;for(var x=c.length;x>0&&c[x-1][2]>y;x--)c[x]=c[x-1];c[x]=[i,A,y];return}for(var T=Infinity,x=0;x<c.length;x++){for(var[i,A,y]=c[x],D=!0,_=0;_<i.length;_++)(y&!1||T>=y)&&Object.keys(v.O).every(ve=>v.O[ve](i[_]))?i.splice(_--,1):(D=!1,y<T&&(T=y));D&&(c.splice(x--,1),E=A())}return E}})(),(()=>{v.n=c=>{var E=c&&c.__esModule?()=>c.default:()=>c;return v.d(E,{a:E}),E}})(),(()=>{v.d=(c,E)=>{for(var i in E)v.o(E,i)&&!v.o(c,i)&&Object.defineProperty(c,i,{enumerable:!0,get:E[i]})}})(),(()=>{v.g=function(){if(typeof globalThis=="object")return globalThis;try{return this||new Function("return this")()}catch(c){if(typeof window=="object")return window}}()})(),(()=>{v.hmd=c=>(c=Object.create(c),c.children||(c.children=[]),Object.defineProperty(c,"exports",{enumerable:!0,set:()=>{throw new Error("ES Modules may not assign module.exports or exports.*, Use ESM export syntax, instead: "+c.id)}}),c)})(),(()=>{v.o=(c,E)=>Object.prototype.hasOwnProperty.call(c,E)})(),(()=>{v.r=c=>{typeof Symbol!="undefined"&&Symbol.toStringTag&&Object.defineProperty(c,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(c,"__esModule",{value:!0})}})(),(()=>{v.nmd=c=>(c.paths=[],c.children||(c.children=[]),c)})(),(()=>{v.j=784})(),(()=>{var c={784:0};v.O.j=A=>c[A]===0;var E=(A,y)=>{var[x,T,D]=y,_,S,j=0;for(_ in T)v.o(T,_)&&(v.m[_]=T[_]);for(D&&D(v),A&&A(y);j<x.length;j++)S=x[j],v.o(c,S)&&c[S]&&c[S][0](),c[x[j]]=0;v.O()},i=self.webpackChunkapps=self.webpackChunkapps||[];i.forEach(E.bind(null,0)),i.push=E.bind(null,i.push.bind(i))})();var ge=v.O(void 0,[736],()=>v(65494));ge=v.O(ge)})();

//# sourceMappingURL=tx.ed00bb9593a4bfb17c5b.js.map