(()=>{var pe={50018:(u,g,o)=>{"use strict";var b=o(18617),w=o(74961),y=o(22462),E=o(48521),v=o(53169);const P=v.iv`
  scrollbar-width: none;
  -ms-overflow-style: none;
  overflow-x: hidden;
  overflow-y: auto;
`;var I=o(66471),$=o.n(I),oe=o(64822),yt=o(77843),C=o(1532);function ge(e){return new oe.y(t=>{if(C.browser.runtime.getURL("").startsWith("safari-web-extension://")){let r=null;const a=(0,yt.F)(1e3).subscribe(()=>{C.browser.storage.local.get(e).then(l=>{const c=l[e];r!==null&&$()(r,c)||(r=c,t.next(c))})});return()=>{a.unsubscribe()}}})}var wt=Object.defineProperty,ye=Object.prototype.hasOwnProperty,J=Object.getOwnPropertySymbols,we=Object.prototype.propertyIsEnumerable,be=(e,t,r)=>t in e?wt(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r,xe=(e,t)=>{for(var r in t||(t={}))ye.call(t,r)&&be(e,r,t[r]);if(J)for(var r of J(t))we.call(t,r)&&be(e,r,t[r]);return e},Ee=(e,t)=>{var r={};for(var a in e)ye.call(e,a)&&t.indexOf(a)<0&&(r[a]=e[a]);if(e!=null&&J)for(var a of J(e))t.indexOf(a)<0&&we.call(e,a)&&(r[a]=e[a]);return r},T=(e,t,r)=>new Promise((a,l)=>{var c=s=>{try{d(r.next(s))}catch(i){l(i)}},f=s=>{try{d(r.throw(s))}catch(i){l(i)}},d=s=>s.done?a(s.value):Promise.resolve(s.value).then(c,f);d((r=r.apply(e,t)).next())});const R="terra_network_storage_v1";function Z(){return T(this,null,function*(){var e;return(e=(yield C.browser.storage.local.get(R))[R])!=null?e:{networks:[],selectedNetwork:void 0}})}function K(e){return T(this,null,function*(){yield C.browser.storage.local.set({[R]:e})})}function Pn(e){return T(this,null,function*(){const{networks:t}=yield Z();return t.find(r=>r.name===e)})}function bt(e){return T(this,null,function*(){const t=yield Z(),{networks:r}=t,a=Ee(t,["networks"]),l=[...r,e];yield K(xe({networks:l},a))})}function xt(e){return T(this,null,function*(){const{networks:t,selectedNetwork:r}=yield Z(),a=t.filter(({name:c})=>e.name!==c),l=e.name===(r==null?void 0:r.name)&&a.length>0?a[0]:r;yield K({networks:a,selectedNetwork:l})})}function Sn(e,t){return T(this,null,function*(){const{networks:r,selectedNetwork:a}=yield Z(),l=r.findIndex(d=>d.name===e);if(l===-1)return;const c=[...r];c.splice(l,1,t);const f=(a==null?void 0:a.name)===e?t:a;yield K({networks:c,selectedNetwork:f})})}function ke(){return new oe.y(e=>{function t(a,l){if(l==="local"&&a[R]){const{newValue:c}=a[R];e.next(c!=null?c:{networks:[],selectedNetwork:void 0})}}C.browser.storage.onChanged.addListener(t);const r=ge(R).subscribe(a=>{e.next(a!=null?a:{networks:[],selectedNetwork:void 0})});return Z().then(a=>{e.next(a)}),()=>{C.browser.storage.onChanged.removeListener(t),r.unsubscribe()}})}function Et(e){return T(this,null,function*(){const t=yield Z(),{selectedNetwork:r}=t,a=Ee(t,["selectedNetwork"]);yield K(xe({selectedNetwork:e},a))})}const kt=v.vJ`
  html,
  body {
    margin: 0;
    background-color: ${({backgroundColor:e})=>e!=null?e:"#0c3694"}
  }
  
  
  html {
    font-family: 'Segoe UI', 'Roboto', 'Oxygen',
    'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue',
    sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    font-size: 16px;
    word-spacing: 1px;
    -ms-text-size-adjust: 100%;
    -webkit-text-size-adjust: 100%;
    box-sizing: border-box;
  }
  
  *,
  *::before,
  *::after {
    box-sizing: border-box;
    margin: 0;
    font-family: 'Segoe UI', 'Roboto', 'Oxygen',
    'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue',
    sans-serif;
  }
  
  ::-webkit-scrollbar {
    display: none;
  }
  
  input::-webkit-outer-spin-button,
  input::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
  }
`;var n=o(27378),Ct=Object.prototype.hasOwnProperty,Ce=Object.getOwnPropertySymbols,Pt=Object.prototype.propertyIsEnumerable,St=(e,t)=>{var r={};for(var a in e)Ct.call(e,a)&&t.indexOf(a)<0&&(r[a]=e[a]);if(e!=null&&Ce)for(var a of Ce(e))t.indexOf(a)<0&&Pt.call(e,a)&&(r[a]=e[a]);return r};const se=(0,n.createContext)();function Ot(e){var{children:t}=e,r=St(e,["children"]);return n.createElement(se.Provider,{value:r},t)}function On(){return useContext(se)}const An=se.Consumer,F=(0,n.createContext)();function At({children:e,addressProvider:t,addressMap:r}){const a=(0,n.useMemo)(()=>{const l=Lt(t,r);return{addressProvider:t,address:l}},[r,t]);return n.createElement(F.Provider,{value:a},e)}function Lt(e,t){return{bluna:{reward:e.blunaReward(""),hub:e.blunaHub(""),airdropRegistry:e.airdrop()},moneyMarket:{market:e.market(""),custody:e.custody(""),overseer:e.overseer(""),oracle:e.oracle(),interestModel:e.interest(),distributionModel:t.mmDistributionModel},liquidation:{liquidationContract:e.liquidation()},anchorToken:{gov:e.gov(),staking:e.staking(),community:e.community(),distributor:e.distributor(),investorLock:e.investorLock(),teamLock:e.teamLock(),collector:e.collector()},terraswap:{blunaLunaPair:e.terraswapblunaLunaPair(),ancUstPair:e.terraswapAncUstPair()},cw20:{bLuna:e.blunaToken(""),aUST:e.aTerra(""),ANC:e.ANC(),AncUstLP:e.terraswapAncUstLPToken(),bLunaLunaLP:e.terraswapblunaLunaLPToken("")}}}function Ln(){const{address:e}=useContext(F);return t=>{switch(t){case e.bluna.reward:return"bLuna / Reward";case e.bluna.hub:return"bLuna / Hub";case e.moneyMarket.market:return"Money Market / Market";case e.moneyMarket.custody:return"Money Market / Custody";case e.moneyMarket.overseer:return"Money Market / Overseer";case e.moneyMarket.oracle:return"Money Market / Oracle";case e.moneyMarket.interestModel:return"Money Market / Interest Model";case e.moneyMarket.distributionModel:return"Money Market / Distribution Model";case e.liquidation.liquidationContract:return"Liquidation";case e.anchorToken.gov:return"Anchor Token / Gov";case e.anchorToken.staking:return"Anchor Token / Staking";case e.anchorToken.community:return"Anchor Token / Community";case e.anchorToken.distributor:return"Anchor Token / Distributor";case e.terraswap.blunaLunaPair:return"Terraswap / bLuna-Luna Pair";case e.terraswap.ancUstPair:return"Terraswap / ANC-UST Pair";case e.cw20.bLuna:return"bLuna";case e.cw20.aUST:return"aUST";case e.cw20.ANC:return"ANC";case e.cw20.AncUstLP:return"ANC-UST-LP";case e.cw20.bLunaLunaLP:return"bLuna-Luna-LP";default:return""}}}function Nn(){return useContext(F)}function Nt(){const{address:e}=(0,n.useContext)(F);return e}const jn=F.Consumer,jt={bLunaHub:"terra1mtwph2juhj0rvjz7dy92gvl6xvukaxu8rfv8ts",blunaToken:"terra1kc87mu460fwkqte29rquh4hc20m54fxwtsx7gp",blunaReward:"terra17yap3mhph35pcwvhza38c2lkj7gzywzy05h7l0",blunaAirdrop:"terra199t7hg7w5vymehhg834r6799pju2q3a0ya7ae9",mmInterestModel:"terra1kq8zzq5hufas9t0kjsjc62t2kucfnx8txf547n",mmOracle:"terra1cgg6yef7qcdm070qftghfulaxmllgmvk77nc7t",mmMarket:"terra1sepfj7s0aeg5967uxnfk4thzlerrsktkpelm5s",mmOverseer:"terra1tmnqgvg567ypvsvk6rwsga3srp7e3lg6u0elp8",mmCustody:"terra1ptjp2vfjrwh0j0faj9r6katm640kgjxnwwq9kn",mmLiquidation:"terra1w9ky73v4g7v98zzdqpqgf3kjmusnx4d4mvnac6",mmDistributionModel:"terra14mufqpr5mevdfn92p4jchpkxp7xr46uyknqjwq",aTerra:"terra1hzh9vpxhsk8253se0vv5jj6etdvxu3nv8z07zu",terraswapblunaLunaPair:"terra1jxazgm67et0ce260kvrpfv50acuushpjsz2y0p",terraswapblunaLunaLPToken:"terra1nuy34nwnsh53ygpc4xprlj263cztw7vc99leh2",terraswapAncUstPair:"terra1gm5p3ner9x9xpwugn9sp6gvhd0lwrtkyrecdn3",terraswapAncUstLPToken:"terra1gecs98vcuktyfkrve9czrpgtg0m3aq586x6gzm",gov:"terra1f32xyep306hhcxxxf7mlyh0ucggc00rm2s9da5",distributor:"terra1mxf7d5updqxfgvchd7lv6575ehhm8qfdttuqzz",collector:"terra14ku9pgw5ld90dexlyju02u4rn6frheexr5f96h",community:"terra12wk8dey0kffwp27l5ucfumczlsc9aned8rqueg",staking:"terra1897an2xux840p9lrh6py3ryankc6mspw49xse3",ANC:"terra14z56l0fp2lsf86zy3hty2z47ezkhnthtr9yq76",airdrop:"terra146ahqn6d3qgdvmj8cj96hh03dzmeedhsf0kxqm",team:"terra1pm54pmw3ej0vfwn3gtn6cdmaqxt0x37e9jt0za",vesting:"terra10evq9zxk2m86n3n3xnpw28jpqwp628c6dzuq42",terraswapFactory:""},Wt={bLunaHub:"terra1fflas6wv4snv8lsda9knvq2w0cyt493r8puh2e",blunaToken:"terra1u0t35drzyy0mujj8rkdyzhe264uls4ug3wdp3x",blunaReward:"terra1ac24j6pdxh53czqyrkr6ygphdeftg7u3958tl2",blunaAirdrop:"terra1334h20c9ewxguw9p9vdxzmr8994qj4qu77ux6q",mmInterestModel:"terra1m25aqupscdw2kw4tnq5ql6hexgr34mr76azh5x",mmOracle:"terra1p4gg3p2ue6qy2qfuxtrmgv2ec3f4jmgqtazum8",mmMarket:"terra15dwd5mj8v59wpj0wvt233mf5efdff808c5tkal",mmOverseer:"terra1qljxd0y3j3gk97025qvl3lgq8ygup4gsksvaxv",mmCustody:"terra1ltnkx0mv7lf2rca9f8w740ashu93ujughy4s7p",mmLiquidation:"terra16vc4v9hhntswzkuunqhncs9yy30mqql3gxlqfe",mmDistributionModel:"terra1u64cezah94sq3ye8y0ung28x3pxc37tv8fth7h",aTerra:"terra1ajt556dpzvjwl0kl5tzku3fc3p3knkg9mkv8jl",terraswapblunaLunaPair:"terra13e4jmcjnwrauvl2fnjdwex0exuzd8zrh5xk29v",terraswapblunaLunaLPToken:"terra1tj4pavqjqjfm0wh73sh7yy9m4uq3m2cpmgva6n",terraswapAncUstPair:"terra1wfvczps2865j0awnurk9m04u7wdmd6qv3fdnvz",terraswapAncUstLPToken:"terra1vg0qyq92ky9z9dp0j9fv5rmr2s80sg605dah6f",gov:"terra16ckeuu7c6ggu52a8se005mg5c0kd2kmuun63cu",distributor:"terra1z7nxemcnm8kp7fs33cs7ge4wfuld307v80gypj",collector:"terra1hlctcrrhcl2azxzcsns467le876cfuzam6jty4",community:"terra17g577z0pqt6tejhceh06y3lyeudfs3v90mzduy",staking:"terra19nxz35c8f7t3ghdxrxherym20tux8eccar0c3k",ANC:"terra1747mad58h0w4y589y3sk84r5efqdev9q4r02pc",airdrop:"terra1u5ywhlve3wugzqslqvm8ks2j0nsvrqjx0mgxpk",terraswapFactory:"",vesting:"terra19f6ktw4qpjj9p9m49y8mhf6pr9807d44xdcus7",team:"terra1x7ted5g0g6ntyqdaqmjwtzcctvvrdju49vs8pl"};var zt=o(31542),Tt=o(65785),A=o(4289),S=o(69635);class Mt extends n.Component{constructor(t){super(t);this.state={error:null}}static getDerivedStateFromError(t){return{error:t}}componentDidCatch(t,r){this.setState({error:t}),console.error(r)}render(){return this.state.error?n.createElement(Bt,null,this.state.error.toString()):this.props.children}}const Bt=v.ZP.pre`
  width: 100%;
  max-height: 500px;
  overflow-y: auto;
  font-size: 12px;
`,N=[{name:"mainnet",chainID:"columbus-4",servers:{lcd:"https://lcd.terra.dev",fcd:"https://fcd.terra.dev",ws:"wss://fcd.terra.dev",mantle:"https://mantle.anchorprotocol.com/"}},{name:"testnet",chainID:"tequila-0004",servers:{lcd:"https://tequila-lcd.terra.dev",fcd:"https://tequila-fcd.terra.dev",ws:"wss://tequila-ws.terra.dev",mantle:"https://tequila-mantle.anchorprotocol.com/"}}],Wn="tx-",zn="content-",Tn=e=>/^tx-[0-9]+$/.test(e),Mn=e=>/^content-[0-9]+$/.test(e),Bn=e=>e.substr(3),Un=e=>e.substr(8),Ut=400,j=50,D=550,It=20,X=["anchor","terra","#147368","#7e1d7b","#113558","#c35942"];var $t=o(86596),Rt=o(6622),W=o(86006),Pe=o(39573),Se=o(84624),Oe=o(97994),Ae=o(71975);const Y=v.ZP.ul`
  list-style: none;
  padding: 0;

  li {
    height: 2.5em;

    display: flex;
    justify-content: space-between;
    align-items: center;

    &:not(:first-child) {
      border-top: 1px dashed #eeeeee;
    }

    a {
      color: inherit;
    }

    color: #000000;

    &[data-selected='false'] {
      color: #bbbbbb;

      &:hover {
        color: #555555;
      }
    }

    svg {
      font-size: 1.2em;
      transform: translateY(0.17em);
    }

    img {
      width: 1.2em;
      height: 1.2em;
      transform: translateY(0.17em) scale(1.2);
    }

    i {
      margin-right: ${({iconMarginRight:e="0.2em"})=>e};
    }

    span {
      display: inline-block;

      &:first-letter {
        text-transform: ${({firstLetterUpperCase:e=!0})=>e?"uppercase":"none"};
      }
    }

    button {
      border: none;
      outline: none;
      background-color: transparent;
      padding: 0;

      cursor: pointer;

      color: #bbbbbb;

      &:hover {
        color: #555555;
      }
    }
  }
`;var M=o(11558),Le=o(56490),Zt=o(78693),Ne=o.n(Zt),Dt=o(80082),Xt=o.n(Dt),qt=Object.defineProperty,Ht=Object.prototype.hasOwnProperty,je=Object.getOwnPropertySymbols,Ft=Object.prototype.propertyIsEnumerable,We=(e,t,r)=>t in e?qt(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r,ze=(e,t)=>{for(var r in t||(t={}))Ht.call(t,r)&&We(e,r,t[r]);if(je)for(var r of je(t))Ft.call(t,r)&&We(e,r,t[r]);return e};const Qt=["en-US","ko-KR"],Vt=Ne(),Jt=ze(ze({},Ne()),Xt());function In(e){switch(e){case"en":case"ko":return!0}return!1}const G=(0,n.createContext)();function Kt({children:e}){const t=(0,n.useMemo)(()=>(0,Le.getBrowserLocale)({fallbackLanguageCodes:["en-US"]}),[]),{locale:r,updateLocale:a}=(0,Le.useLocale)(t);return n.createElement(G.Provider,{value:{locale:r,locales:Qt,updateLocale:a}},e)}function Yt(){return(0,n.useContext)(G)}function Gt(){const{locale:e}=(0,n.useContext)(G);return{locale:e.substr(0,2),messages:e==="ko-KR"?Jt:Vt}}const $n=G.Consumer;function _t({className:e}){const t=(0,S.k6)(),{locale:r,locales:a,updateLocale:l}=Yt(),[c,f]=(0,n.useState)(N),[d,s]=(0,n.useState)(()=>N[0]),[i,m]=(0,n.useState)(null),O=!!i;return(0,n.useEffect)(()=>{const h=ke().subscribe(({networks:L,selectedNetwork:le})=>{f([...N,...L]),s(le!=null?le:N[0])});return()=>{h.unsubscribe()}},[]),n.createElement($t.Z,{onClickAway:()=>m(null)},n.createElement("div",{className:e},n.createElement(er,{onClick:({currentTarget:h})=>{m(L=>L?null:h)}},n.createElement("div",null,n.createElement("i",null,n.createElement(Pe.Z,null)),n.createElement("span",null,d.name),n.createElement("i",null,n.createElement(Se.Z,null)),n.createElement("span",null,n.createElement(M.Z,{id:`locale.${r}`})))),n.createElement(Rt.Z,{open:O,anchorEl:i,placement:"bottom"},n.createElement(nr,null,n.createElement("h2",null,"Network"),n.createElement(Y,null,c.map(h=>n.createElement("li",{key:h.name,"data-selected":h.name===d.name},n.createElement("div",{style:{cursor:"pointer"},onClick:()=>{Et(h),m(null)}},n.createElement("i",null,n.createElement(Pe.Z,null)),n.createElement("span",null,h.name)),N.indexOf(h)===-1&&n.createElement("button",{onClick:()=>{xt(h),m(null)}},n.createElement(Oe.Z,null)))),n.createElement("li",{"data-selected":"false"},n.createElement("div",{style:{cursor:"pointer"},onClick:()=>{t.push("/network/create"),m(null)}},n.createElement("i",null,n.createElement(Ae.Z,null)),n.createElement("span",null,"Add a new network")))),n.createElement("h2",null,"Language"),n.createElement(Y,null,a.map(h=>n.createElement("li",{key:h,"data-selected":h===r},n.createElement("div",{style:{cursor:"pointer"},onClick:()=>{l(h),m(null)}},n.createElement("i",null,n.createElement(Se.Z,null)),n.createElement("span",null,n.createElement(M.Z,{id:"locale."+h}))))))))))}const er=(0,v.ZP)(W.Z)`
  && {
    color: #ffffff;
    font-size: 12px;
    font-weight: normal;
    text-transform: none;

    div {
      display: flex;
      align-items: center;

      i {
        svg {
          font-size: 1.2em;
          transform: translateY(0.2em);
        }

        margin-right: 0.3em;

        &:nth-of-type(2) {
          margin-left: 1em;
        }
      }

      span:first-letter {
        text-transform: uppercase;
      }
    }
  }
`,tr=(0,v.ZP)(_t)`
  position: relative;
  display: inline-block;
`,rr=v.F4`
  0% {
    opacity: 0;
    transform: scale(1, 0.4);
  }
  
  100% {
    opacity: 1;
    transform: scale(1, 1);
  }
`,nr=v.ZP.div`
  min-width: 200px;

  font-size: 13px;

  background-color: #ffffff;
  box-shadow: 0 0 21px 4px rgba(0, 0, 0, 0.3);
  border-radius: 12px;

  padding: 1em;

  transform-origin: top;
  animation: ${rr} 0.1s ease-out;

  h2 {
    font-size: 1.2em;
    font-weight: normal;
    text-align: center;

    margin-bottom: 0.5em;

    &:not(:first-child) {
      margin-top: 1.2em;
    }
  }
`;function ar(){return n.createElement("svg",{viewBox:"0 0 128 17"},n.createElement("path",{d:"M32.9 3.56a4.7 4.7 0 0 1 1.52-.06c.2.01.4.04.58.09v3.34a4.8 4.8 0 0 0-1.54-.25c-.68 0-1.23.1-1.62.3-.4.19-.71.46-.93.8a3.12 3.12 0 0 0-.42 1.26 11.62 11.62 0 0 0-.1 1.61v4.94H26.8V3.76h3.6v1.33a4.58 4.58 0 0 1 2.5-1.53zm9.74 0a4.68 4.68 0 0 1 1.52-.06c.2.01.4.04.57.09v3.34a4.8 4.8 0 0 0-1.54-.25c-.68 0-1.22.1-1.62.3-.4.19-.71.46-.92.8a3.12 3.12 0 0 0-.42 1.26 11.62 11.62 0 0 0-.1 1.61v4.94h-3.6V3.76h3.6v1.33a4.59 4.59 0 0 1 2.5-1.53zM.68.46h13.8v3.23H9.5v11.84H5.66V3.7H.68V.46zM17.05 4.4a7.61 7.61 0 0 1 2.58-.42c.85 0 1.62.14 2.3.42a4.86 4.86 0 0 1 1.76 1.23c.48.53.85 1.17 1.11 1.92.26.74.4 1.57.4 2.49v1.11h-8.5c.15.68.47 1.23.95 1.63.5.4 1.1.6 1.8.6.6 0 1.12-.12 1.53-.39a4.25 4.25 0 0 0 1.1-1l2.55 1.83a5.92 5.92 0 0 1-2.22 1.69c-.87.38-1.77.58-2.7.59h-.17a7.8 7.8 0 0 1-2.49-.43 6.19 6.19 0 0 1-2.1-1.22 5.74 5.74 0 0 1-1.4-1.92c-.34-.74-.51-1.57-.51-2.5a5.84 5.84 0 0 1 1.91-4.4 6.23 6.23 0 0 1 2.1-1.23zm-.14 3.5a2.19 2.19 0 0 0-.2.82h4.83a2.06 2.06 0 0 0-.61-1.54 2.2 2.2 0 0 0-1.63-.64 2.71 2.71 0 0 0-1.87.67c-.22.2-.4.43-.52.7zM46.3 4.93a11.2 11.2 0 0 1 4.75-.95c1.9 0 3.26.48 4.13 1.32.92.88 1.33 2.17 1.33 3.75v6.83h-3.36V14.6a4.8 4.8 0 0 1-3.7 1.5c-2.31 0-4.21-1.27-4.21-3.6v-.04c0-2.57 2.03-3.76 4.94-3.76 1.23 0 2.12.2 3 .49v-.2c0-1.38-.9-2.15-2.63-2.15-1.33 0-2.27.24-3.38.63l-.87-2.54zm2.29 7.44c0 .9.78 1.43 1.9 1.43 1.63 0 2.72-.86 2.72-2.06v-.2a.59.59 0 0 0-.4-.55 5.8 5.8 0 0 0-1.82-.28c-1.48 0-2.4.56-2.4 1.62v.04zm14.35 1.05l1.02-1.2a6.9 6.9 0 0 0 4.98 2.06c1.95 0 3.24-1.05 3.24-2.48v-.05c0-1.35-.73-2.12-3.78-2.77-3.34-.73-4.87-1.81-4.87-4.2v-.05c0-2.3 2-3.98 4.77-3.98 2.12 0 3.63.6 5.1 1.8l-.95 1.26a6.36 6.36 0 0 0-4.2-1.58c-1.88 0-3.08 1.04-3.08 2.35v.04c0 1.38.74 2.15 3.94 2.84 3.24.7 4.73 1.9 4.73 4.13v.04c0 2.5-2.08 4.12-4.96 4.12-2.3 0-4.2-.77-5.94-2.33zm13.45-.73V6.2h-1.5V4.77h1.5V1.52H78v3.25h3.4v1.42H78v6.3c0 1.3.73 1.79 1.8 1.79.54 0 1-.1 1.56-.38v1.38a4 4 0 0 1-1.93.46c-1.72 0-3.03-.86-3.03-3.05zm13.95-1.1v-1.05a11.15 11.15 0 0 0-3.16-.45c-2.01 0-3.13.87-3.13 2.23v.04c0 1.35 1.24 2.14 2.7 2.14 1.97 0 3.59-1.2 3.59-2.91zm-7.9.83v-.04c0-2.27 1.86-3.48 4.58-3.48 1.37 0 2.34.19 3.3.46v-.38c0-1.94-1.19-2.94-3.2-2.94-1.27 0-2.26.33-3.26.8l-.48-1.32a8.83 8.83 0 0 1 3.9-.9c1.52 0 2.68.4 3.47 1.2.73.72 1.1 1.76 1.1 3.14v6.58h-1.53v-1.62a4.7 4.7 0 0 1-3.88 1.85c-2 0-4-1.14-4-3.35zm12.3.27V6.2h-1.5V4.77h1.5V1.52h1.6v3.25h3.4v1.42h-3.4v6.3c0 1.3.72 1.79 1.8 1.79.54 0 1-.1 1.56-.38v1.38a4 4 0 0 1-1.93.46c-1.73 0-3.03-.86-3.03-3.05zm6.99 2.86V4.77h1.6v10.78h-1.6zm-.1-13.13V.65h1.82v1.77h-1.82zm13.32 7.8v-.05c0-2.31-1.72-4.21-3.99-4.21-2.32 0-3.92 1.9-3.92 4.17v.04c0 2.31 1.7 4.19 3.96 4.19 2.33 0 3.95-1.88 3.95-4.15zm-9.55 0v-.05a5.57 5.57 0 0 1 5.6-5.63 5.53 5.53 0 0 1 5.59 5.59v.04a5.58 5.58 0 0 1-5.63 5.63 5.5 5.5 0 0 1-5.56-5.59zm13.1-5.45h1.6v1.88a4.06 4.06 0 0 1 3.67-2.1c2.6 0 4.1 1.74 4.1 4.3v6.7h-1.6v-6.3c0-2-1.07-3.25-2.96-3.25-1.85 0-3.22 1.36-3.22 3.38v6.17h-1.6V4.77z",fill:"currentColor"}))}const Rn=o.p+"Logo.2bf95ab2fe0f078ce06486b8f700f339.svg";function lr({className:e}){return n.createElement("header",{className:e},n.createElement(A.rU,{className:"logo",to:"/"},n.createElement(ar,null)),n.createElement(tr,null))}const or=(0,v.ZP)(lr)`
  min-height: ${j}px;
  max-height: ${j}px;

  padding: 0 ${It}px;

  .logo {
    color: #ffffff;
    font-size: 0;

    svg {
      color: currentColor;
      width: 100px;
    }
  }

  display: flex;
  justify-content: space-between;
  align-items: center;
`;var sr=o(47290),cr=o(45530);function ir({children:e,injectFirst:t=!0,theme:r}){return n.createElement(sr.ZP,{injectFirst:t},n.createElement(v.f6,{theme:r},n.createElement(cr.Z,{theme:r},e)))}var x=o(78781),ur=o(79316),dr=o(99815);const Te=(0,v.ZP)(W.Z).attrs({size:"small"})`
  outline: none;

  border: 0;
  height: 20px;
  border-radius: 15px;

  cursor: pointer;

  user-select: none;

  font-size: 10px;
  font-weight: 300;
  text-align: center;

  color: #aaaaaa;
  background-color: #eeeeee;

  &:hover {
    color: #777777;
    background-color: #e5e5e5;
  }

  &:active {
    color: #777777;
    background-color: #e5e5e5;
  }

  &:disabled {
    opacity: 0.3;
  }

  .MuiButton-startIcon {
    margin-right: 4px;
  }

  .MuiButton-iconSizeSmall > *:first-child {
    font-size: 1.3em;
  }
`,B=700,U=380,mr=U/B;var fr=Object.defineProperty,Me=Object.prototype.hasOwnProperty,_=Object.getOwnPropertySymbols,Be=Object.prototype.propertyIsEnumerable,Ue=(e,t,r)=>t in e?fr(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r,pr=(e,t)=>{for(var r in t||(t={}))Me.call(t,r)&&Ue(e,r,t[r]);if(_)for(var r of _(t))Be.call(t,r)&&Ue(e,r,t[r]);return e},vr=(e,t)=>{var r={};for(var a in e)Me.call(e,a)&&t.indexOf(a)<0&&(r[a]=e[a]);if(e!=null&&_)for(var a of _(e))t.indexOf(a)<0&&Be.call(e,a)&&(r[a]=e[a]);return r};function hr(e){var{variant:t,borderRadius:r,children:a}=e,l=vr(e,["variant","borderRadius","children"]);return n.createElement("svg",pr({viewBox:`0 0 ${B} ${U}`},l),a)}const gr=(0,v.ZP)(hr)`
  border-radius: ${({variant:e="medium",borderRadius:t=e==="medium"?30:20})=>t}px;

  background-color: #ffffff;
  border: 3px dashed #aaaaaa;

  svg {
    color: #aaaaaa;
  }
`;var yr=Object.defineProperty,Ie=Object.prototype.hasOwnProperty,ee=Object.getOwnPropertySymbols,$e=Object.prototype.propertyIsEnumerable,Re=(e,t,r)=>t in e?yr(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r,wr=(e,t)=>{for(var r in t||(t={}))Ie.call(t,r)&&Re(e,r,t[r]);if(ee)for(var r of ee(t))$e.call(t,r)&&Re(e,r,t[r]);return e},br=(e,t)=>{var r={};for(var a in e)Ie.call(e,a)&&t.indexOf(a)<0&&(r[a]=e[a]);if(e!=null&&ee)for(var a of ee(e))t.indexOf(a)<0&&$e.call(e,a)&&(r[a]=e[a]);return r};function xr(e){var{variant:t="medium",borderRadius:r,textColor:a}=e,l=br(e,["variant","borderRadius","textColor"]);return n.createElement("svg",wr({viewBox:`0 0 ${B} ${U}`},l))}const Er=(0,v.ZP)(xr)`
  box-shadow: 0 2px 6px 2px rgba(0, 0, 0, 0.43);

  border-radius: ${({variant:e="medium",borderRadius:t=e==="medium"?30:20})=>t}px;

  text {
    font-family: sans-serif;
    fill: ${({textColor:e="#ffffff"})=>e};
  }
`;function kr({name:e,terraAddress:t,variant:r}){return r==="medium"?n.createElement(n.Fragment,null,n.createElement("text",{x:60,y:250,fontSize:23,opacity:.7},t),n.createElement("text",{x:60,y:300,fontSize:35},e)):n.createElement(n.Fragment,null,n.createElement("text",{x:60,y:220,fontSize:40,opacity:.7},(0,x.truncate)(t)),n.createElement("text",{x:60,y:300,fontSize:60},e))}var Cr=Object.defineProperty,Ze=Object.prototype.hasOwnProperty,te=Object.getOwnPropertySymbols,De=Object.prototype.propertyIsEnumerable,Xe=(e,t,r)=>t in e?Cr(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r,Pr=(e,t)=>{for(var r in t||(t={}))Ze.call(t,r)&&Xe(e,r,t[r]);if(te)for(var r of te(t))De.call(t,r)&&Xe(e,r,t[r]);return e},Sr=(e,t)=>{var r={};for(var a in e)Ze.call(e,a)&&t.indexOf(a)<0&&(r[a]=e[a]);if(e!=null&&te)for(var a of te(e))t.indexOf(a)<0&&De.call(e,a)&&(r[a]=e[a]);return r};function qe(e){var{design:t,name:r,terraAddress:a,variant:l="medium",ref:c}=e,f=Sr(e,["design","name","terraAddress","variant","ref"]);const d=(0,n.useMemo)(()=>(0,n.isValidElement)(t)?t:t==="anchor"?n.createElement("image",{xlinkHref:"/assets/wallet/Anchor.svg",width:B,height:U}):t==="terra"?n.createElement("image",{xlinkHref:"/assets/wallet/Terra.svg",width:B,height:U}):typeof t=="string"?n.createElement("rect",{fill:t,width:B+20,height:U+20}):n.createElement("image",{xlinkHref:"/assets/wallet/Terra.svg",width:B,height:U}),[t]);return n.createElement(Er,Pr({variant:l},f),d,n.createElement(kr,{name:r,terraAddress:a,variant:l}))}var Or=o(81347),Ar=Object.defineProperty,He=Object.prototype.hasOwnProperty,re=Object.getOwnPropertySymbols,Fe=Object.prototype.propertyIsEnumerable,Qe=(e,t,r)=>t in e?Ar(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r,Lr=(e,t)=>{for(var r in t||(t={}))He.call(t,r)&&Qe(e,r,t[r]);if(re)for(var r of re(t))Fe.call(t,r)&&Qe(e,r,t[r]);return e},Nr=(e,t)=>{var r={};for(var a in e)He.call(e,a)&&t.indexOf(a)<0&&(r[a]=e[a]);if(e!=null&&re)for(var a of re(e))t.indexOf(a)<0&&Fe.call(e,a)&&(r[a]=e[a]);return r};const ce=20;function jr(e){var{cardWidth:t,children:r,selectedIndex:a,onSelect:l,onCreate:c}=e,f=Nr(e,["cardWidth","children","selectedIndex","onSelect","onCreate"]);const d=(0,n.useMemo)(()=>{if(!r)return null;const s=Array.isArray(r)?r:[r];return s.length===0?null:s.map((i,m)=>{const O=t*(m-a),h=1-Math.abs((m-a)*.2),L=1-Math.abs((m-a)*.4);return n.createElement("li",{key:"card"+m,onClick:()=>a!==m&&l(m),style:{transform:`translate(${O-ce}px, ${-ce}px) scale(${h})`,opacity:L,filter:Math.abs(m-a)===1?"blur(2px)":void 0,cursor:a!==m?"pointer":void 0}},i)})},[t,r,l,a]);return n.createElement("ul",Lr({},f),d||(typeof c=="function"?n.createElement("li",{onClick:c,style:{cursor:"pointer"}},n.createElement(gr,null,n.createElement("g",{transform:"translate(350 190)"},n.createElement("g",{transform:"translate(-100 -100)"},n.createElement(Or.Z,{width:"200",height:"200"}))))):null))}const Ve=(0,v.ZP)(jr)`
  list-style: none;
  padding: 0;
  margin: 20px 0;

  position: relative;

  min-width: ${({cardWidth:e})=>e}px;
  max-width: ${({cardWidth:e})=>e}px;
  height: ${({cardWidth:e})=>Math.ceil(e*mr)}px;

  > li {
    position: absolute;
    left: 0;
    top: 0;
    padding: ${ce}px;

    user-select: none;

    > svg {
      width: ${({cardWidth:e})=>e}px;
    }

    will-change: transform, opacity, filter;
    transition: transform 0.3s ease-in-out, opacity 0.3s;
  }
`;var q=(e,t,r)=>new Promise((a,l)=>{var c=s=>{try{d(r.next(s))}catch(i){l(i)}},f=s=>{try{d(r.throw(s))}catch(i){l(i)}},d=s=>s.done?a(s.value):Promise.resolve(s.value).then(c,f);d((r=r.apply(e,t)).next())});const H="terra_wallet_storage_v1";function Q(){return q(this,null,function*(){var e;return(e=(yield C.browser.storage.local.get(H))[H])!=null?e:[]})}function ie(e){return q(this,null,function*(){yield C.browser.storage.local.set({[H]:e})})}function Wr(e){return q(this,null,function*(){return(yield Q()).find(r=>r.terraAddress===e)})}function Je(e){return q(this,null,function*(){const r=[...yield Q(),e];yield ie(r)})}function zr(e){return q(this,null,function*(){const r=(yield Q()).filter(({terraAddress:a})=>a!==e.terraAddress);yield ie(r)})}function Tr(e,t){return q(this,null,function*(){const r=yield Q(),a=r.findIndex(c=>c.terraAddress===e);if(a===-1)return;const l=[...r];l.splice(a,1,t),yield ie(l)})}function Mr(){return new oe.y(e=>{function t(a,l){if(l==="local"&&a[H]){const{newValue:c}=a[H];e.next(c!=null?c:[])}}C.browser.storage.onChanged.addListener(t);const r=ge(H).subscribe(a=>{e.next(a!=null?a:[])});return Q().then(a=>{e.next(a)}),()=>{C.browser.storage.onChanged.removeListener(t),r.unsubscribe()}})}var Br=o(15373),V=o.n(Br),ue=o(10794),Ur=Object.defineProperty,Ir=Object.prototype.hasOwnProperty,Ke=Object.getOwnPropertySymbols,$r=Object.prototype.propertyIsEnumerable,Ye=(e,t,r)=>t in e?Ur(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r,Ge=(e,t)=>{for(var r in t||(t={}))Ir.call(t,r)&&Ye(e,r,t[r]);if(Ke)for(var r of Ke(t))$r.call(t,r)&&Ye(e,r,t[r]);return e};function Rr(e,t){return(0,n.useCallback)(r=>e(r).then(a=>Ge(Ge({},a),{data:(0,ue.map)(a.data,t)})),[t,e])}var Zr=Object.defineProperty,_e=Object.prototype.hasOwnProperty,ne=Object.getOwnPropertySymbols,et=Object.prototype.propertyIsEnumerable,tt=(e,t,r)=>t in e?Zr(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r,rt=(e,t)=>{for(var r in t||(t={}))_e.call(t,r)&&tt(e,r,t[r]);if(ne)for(var r of ne(t))et.call(t,r)&&tt(e,r,t[r]);return e},Dr=(e,t)=>{var r={};for(var a in e)_e.call(e,a)&&t.indexOf(a)<0&&(r[a]=e[a]);if(e!=null&&ne)for(var a of ne(e))t.indexOf(a)<0&&et.call(e,a)&&(r[a]=e[a]);return r};const nt=(0,ue.createMap)({uUSD:(e,{bankBalances:t})=>{var r,a;return(a=(r=t.Result.find(({Denom:l})=>l==="uusd"))==null?void 0:r.Amount)!=null?a:"0"},uLuna:(e,{bankBalances:t})=>{var r,a;return(a=(r=t.Result.find(({Denom:l})=>l==="uluna"))==null?void 0:r.Amount)!=null?a:"0"},uaUST:(e,{uaUSTBalance:t})=>JSON.parse(t.Result).balance,ubLuna:(e,{ubLunaBalance:t})=>JSON.parse(t.Result).balance,uANC:(e,{uANCBalance:t})=>JSON.parse(t.Result).balance,uAncUstLP:(e,{uAncUstLPBalance:t})=>JSON.parse(t.Result).balance,ubLunaLunaLP:(e,{ubLunaLunaLPBalance:t})=>JSON.parse(t.Result).balance}),Zn={__data:{bankBalances:{Result:[{Denom:"uusd",Amount:"0"},{Denom:"uluna",Amount:"0"}]},uaUSTBalance:{Result:""},ubLunaBalance:{Result:""},uANCBalance:{Result:""},uAncUstLPBalance:{Result:""},ubLunaLunaLPBalance:{Result:""}},uUSD:"0",uaUST:"0",uLuna:"0",ubLuna:"0",uANC:"0",uAncUstLP:"0",ubLunaLunaLP:"0"};function Xr({walletAddress:e,bAssetTokenAddress:t,aTokenAddress:r,ANCTokenAddress:a,AncUstLPTokenAddress:l,bLunaLunaLPTokenAddress:c}){return{walletAddress:e,bAssetTokenAddress:t,bAssetTokenBalanceQuery:JSON.stringify({balance:{address:e}}),aTokenAddress:r,aTokenBalanceQuery:JSON.stringify({balance:{address:e}}),ANCTokenAddress:a,ANCTokenBalanceQuery:JSON.stringify({balance:{address:e}}),AncUstLPTokenAddress:l,AncUstLPTokenBalanceQuery:JSON.stringify({balance:{address:e}}),bLunaLunaLPTokenAddress:c,bLunaLunaLPTokenBalanceQuery:JSON.stringify({balance:{address:e}})}}const qr=y.Ps`
  query __userBalances(
    $walletAddress: String!
    $bAssetTokenAddress: String!
    $bAssetTokenBalanceQuery: String!
    $aTokenAddress: String!
    $aTokenBalanceQuery: String!
    $ANCTokenAddress: String!
    $ANCTokenBalanceQuery: String!
    $AncUstLPTokenAddress: String!
    $AncUstLPTokenBalanceQuery: String!
    $bLunaLunaLPTokenAddress: String!
    $bLunaLunaLPTokenBalanceQuery: String!
  ) {
    # uluna, ukrt, uust...
    bankBalances: BankBalancesAddress(Address: $walletAddress) {
      Result {
        Denom
        Amount
      }
    }

    # ubluna
    ubLunaBalance: WasmContractsContractAddressStore(
      ContractAddress: $bAssetTokenAddress
      QueryMsg: $bAssetTokenBalanceQuery
    ) {
      Result
    }

    # uaust
    uaUSTBalance: WasmContractsContractAddressStore(
      ContractAddress: $aTokenAddress
      QueryMsg: $aTokenBalanceQuery
    ) {
      Result
    }

    # uanc
    uANCBalance: WasmContractsContractAddressStore(
      ContractAddress: $ANCTokenAddress
      QueryMsg: $ANCTokenBalanceQuery
    ) {
      Result
    }

    # u anc ust lp
    uAncUstLPBalance: WasmContractsContractAddressStore(
      ContractAddress: $AncUstLPTokenAddress
      QueryMsg: $AncUstLPTokenBalanceQuery
    ) {
      Result
    }

    # u bluna luna lp
    ubLunaLunaLPBalance: WasmContractsContractAddressStore(
      ContractAddress: $bLunaLunaLPTokenAddress
      QueryMsg: $bLunaLunaLPTokenBalanceQuery
    ) {
      Result
    }
  }
`;function Hr({selectedWallet:e}){const{cw20:t}=Nt(),r=(0,n.useMemo)(()=>{if(!!e)return Xr({walletAddress:e.terraAddress,bAssetTokenAddress:t.bLuna,aTokenAddress:t.aUST,ANCTokenAddress:t.ANC,AncUstLPTokenAddress:t.AncUstLP,bLunaLunaLPTokenAddress:t.bLunaLunaLP})},[t.ANC,t.AncUstLP,t.aUST,t.bLuna,t.bLunaLunaLP,e]),a=(0,w.useQuery)(qr,{skip:!r,fetchPolicy:"network-only",nextFetchPolicy:"cache-first",variables:r}),{previousData:l,data:c=l,refetch:f}=a,d=Dr(a,["previousData","data","refetch"]),s=(0,ue.useMap)(c,nt),i=Rr(f,nt);return rt(rt({},d),{data:s,refetch:i})}function Fr({className:e}){const t=(0,S.k6)(),[r,a]=(0,n.useState)([]);(0,n.useEffect)(()=>{const h=Mr().subscribe(L=>{a(L)});return()=>{h.unsubscribe()}},[]);const l=(0,n.useMemo)(()=>r.map(({name:h,terraAddress:L,design:le})=>n.createElement(qe,{key:h,name:h,terraAddress:L,design:le})),[r]),[c,f]=(0,n.useState)(0),{data:{uUSD:d,uaUST:s,uLuna:i,ubLuna:m,uANC:O}}=Hr({selectedWallet:r[c]});return n.createElement("section",{className:e},n.createElement("header",null,n.createElement(Ve,{className:"wallet-cards",cardWidth:276,selectedIndex:c,onSelect:f,onCreate:()=>t.push("/wallet/create")},l),r.length>0&&!!r[c]&&n.createElement("div",{className:"wallet-actions"},n.createElement(Te,{startIcon:n.createElement(ur.Z,null),component:A.rU,to:`/wallets/${r[c].terraAddress}/password`},n.createElement(M.Z,{id:"wallet.change-password"})),n.createElement(Te,{startIcon:n.createElement(Oe.Z,null),onClick:()=>zr(r[c])},n.createElement(M.Z,{id:"wallet.delete"})))),r.length===0&&n.createElement("section",{className:"empty-wallets"},n.createElement(M.Z,{id:"wallet.empty"})),n.createElement(Y,{className:"user-balances",iconMarginRight:"0.6em",firstLetterUpperCase:!1},i&&V()(i).gt(0)&&n.createElement("li",null,n.createElement("div",null,n.createElement("i",null,n.createElement("img",{src:"https://assets.terra.money/icon/60/Luna.png",alt:"Luna"})),n.createElement("span",null,"Luna")),n.createElement("div",null,n.createElement(x.AnimateNumber,{format:x.formatLuna},(0,x.demicrofy)(i)))),d&&V()(d).gt(0)&&n.createElement("li",null,n.createElement("div",null,n.createElement("i",null,n.createElement("img",{src:"https://assets.terra.money/icon/60/UST.png",alt:"UST"})),n.createElement("span",null,"UST")),n.createElement("div",null,n.createElement(x.AnimateNumber,{format:x.formatUST},(0,x.demicrofy)(d)))),O&&V()(O).gt(0)&&n.createElement("li",null,n.createElement("div",null,n.createElement("i",null,n.createElement("img",{src:"https://whitelist.anchorprotocol.com/logo/ANC.png",alt:"ANC"})),n.createElement("span",null,"ANC")),n.createElement("div",null,n.createElement(x.AnimateNumber,{format:x.formatANC},(0,x.demicrofy)(O)))),m&&V()(m).gt(0)&&n.createElement("li",null,n.createElement("div",null,n.createElement("i",null,n.createElement("img",{src:"https://whitelist.anchorprotocol.com/logo/bLUNA.png",alt:"bLUNA"})),n.createElement("span",null,"bLUNA")),n.createElement("div",null,n.createElement(x.AnimateNumber,{format:x.formatLuna},(0,x.demicrofy)(m)))),s&&V()(s).gt(0)&&n.createElement("li",null,n.createElement("div",null,n.createElement("i",null,n.createElement("img",{src:"https://whitelist.anchorprotocol.com/logo/aUST.png",alt:"aUST"})),n.createElement("span",null,"aUST")),n.createElement("div",null,n.createElement(x.AnimateNumber,{format:x.formatAUST},(0,x.demicrofy)(s))))),n.createElement(Y,{className:"wallets-actions",iconMarginRight:"0.6em"},n.createElement("li",null,n.createElement(A.rU,{to:"/wallet/create"},n.createElement("i",null,n.createElement(Ae.Z,null)),n.createElement("span",null,n.createElement(M.Z,{id:"wallet.new"})))),n.createElement("li",null,n.createElement(A.rU,{to:"/wallet/recover"},n.createElement("i",null,n.createElement(dr.Z,null)),n.createElement("span",null,n.createElement(M.Z,{id:"wallet.recover"}))))))}const Qr=(0,v.ZP)(Fr)`
  .wallet-cards {
    margin: 20px auto 0 auto;
  }

  .wallet-actions {
    height: 50px;

    display: flex;
    justify-content: center;
    align-items: center;

    > :not(:first-child) {
      margin-left: 10px;
    }
  }

  .empty-wallets {
    margin: 30px 0 20px 0;
    text-align: center;
  }

  .user-balances,
  .wallets-actions {
    margin-top: 10px;
    font-size: 17px;
  }
`;var Vr=(e,t,r)=>new Promise((a,l)=>{var c=s=>{try{d(r.next(s))}catch(i){l(i)}},f=s=>{try{d(r.throw(s))}catch(i){l(i)}},d=s=>s.done?a(s.value):Promise.resolve(s.value).then(c,f);d((r=r.apply(e,t)).next())});const at=JSON.stringify(N[0].servers,null,2);function Jr({history:e}){const[t,r]=(0,n.useState)(""),[a,l]=(0,n.useState)(""),[c,f]=(0,n.useState)(at),[d,s]=(0,n.useState)(null),i=(0,n.useCallback)(()=>Vr(this,null,function*(){let m;try{if(m=JSON.parse(c),typeof m.lcd!="string"){s("lcd is required!");return}}catch(h){s("servers is not a json string");return}yield bt({name:t,chainID:a,servers:m}),e.push("/")}),[a,e,t,c]);return n.createElement("section",null,n.createElement("div",null,n.createElement(A.rU,{to:"/"},"Back to Main"),n.createElement("h3",null,"Network Name"),n.createElement("input",{type:"text",value:t,onChange:({target:m})=>r(m.value)}),n.createElement("h3",null,"Chain ID"),n.createElement("input",{type:"text",value:a,onChange:({target:m})=>l(m.value)}),n.createElement("h3",null,"Servers"),n.createElement("textarea",{style:{width:"100%",height:250},placeholder:at,value:c,onChange:({target:m})=>f(m.value)})),n.createElement("div",null,d&&n.createElement("div",null,d),n.createElement("button",{onClick:i},"Create Network")))}var z=o(74296);const de=v.ZP.div`
  display: flex;
  flex-direction: column;

  > * {
    margin-bottom: 1.5em;
  }
`,me=v.ZP.section`
  font-size: 12px;

  header {
    h1 {
      font-size: 1.4em;
      font-weight: normal;

      text-align: center;
    }

    margin-bottom: 1em;
  }

  footer {
    margin-top: 2em;

    display: flex;

    > * {
      flex: 1;

      &:not(:first-child) {
        margin-left: 0.5em;
      }
    }
  }
`;var Kr=o(76679),k=o.n(Kr);const lt=256,ot=100;function Yr(e,t){try{const r=k().lib.WordArray.random(128/8),a=k().PBKDF2(t,r,{keySize:lt/32,iterations:ot}),l=k().lib.WordArray.random(128/8),c=k().AES.encrypt(e,a,{iv:l,padding:k().pad.Pkcs7,mode:k().mode.CBC});return r.toString()+l.toString()+c.toString()}catch(r){return""}}function Gr(e,t){try{const r=k().enc.Hex.parse(e.substr(0,32)),a=k().enc.Hex.parse(e.substr(32,32)),l=e.substring(64),c=k().PBKDF2(t,r,{keySize:lt/32,iterations:ot});return k().AES.decrypt(l,c,{iv:a,padding:k().pad.Pkcs7,mode:k().mode.CBC}).toString(k().enc.Utf8)}catch(r){return""}}var st=o(82298);function _r(){return new st.MnemonicKey({coinType:330})}function en(e){return new st.MnemonicKey({mnemonic:e,coinType:330})}function ct(e){var t,r;return{privateKey:e.privateKey.toString("hex"),publicKey:(r=(t=e.publicKey)==null?void 0:t.toString("hex"))!=null?r:"",terraAddress:e.accAddress}}function fe(e,t){return Yr(JSON.stringify(e),t)}function tn(e,t){return JSON.parse(Gr(e,t))}var rn=Object.defineProperty,nn=Object.prototype.hasOwnProperty,it=Object.getOwnPropertySymbols,an=Object.prototype.propertyIsEnumerable,ut=(e,t,r)=>t in e?rn(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r,dt=(e,t)=>{for(var r in t||(t={}))nn.call(t,r)&&ut(e,r,t[r]);if(it)for(var r of it(t))an.call(t,r)&&ut(e,r,t[r]);return e},ln=(e,t,r)=>new Promise((a,l)=>{var c=s=>{try{d(r.next(s))}catch(i){l(i)}},f=s=>{try{d(r.throw(s))}catch(i){l(i)}},d=s=>s.done?a(s.value):Promise.resolve(s.value).then(c,f);d((r=r.apply(e,t)).next())});function on({match:e,history:t}){const[r,a]=(0,n.useState)(null),[l,c]=(0,n.useState)(""),[f,d]=(0,n.useState)("");(0,n.useEffect)(()=>{if(!e)a(null);else{const{terraAddress:i}=e.params;Wr(i).then(m=>a(m!=null?m:null))}},[e]);const s=(0,n.useCallback)(()=>ln(this,null,function*(){if(!r)return;const i=tn(r.encryptedWallet,l),m=dt(dt({},r),{encryptedWallet:fe(i,f)});yield Tr(r.terraAddress,m),t.push("/")}),[l,t,f,r]);return r?n.createElement(me,null,n.createElement("header",null,n.createElement("h1",null,"Change Wallet Password")),n.createElement(de,null,n.createElement(z.Z,{type:"text",size:"small",label:"WALLET NAME",InputLabelProps:{shrink:!0},value:r.name,readOnly:!0}),n.createElement(z.Z,{type:"password",size:"small",label:"CURRENT PASSWORD",InputLabelProps:{shrink:!0},value:l,onChange:({target:i})=>c(i.value)}),n.createElement(z.Z,{type:"password",size:"small",label:"NEW PASSWORD",InputLabelProps:{shrink:!0},value:f,onChange:({target:i})=>d(i.value)})),n.createElement("footer",null,n.createElement(W.Z,{variant:"contained",color:"secondary",component:A.rU,to:"/"},"Cancel"),n.createElement(W.Z,{variant:"contained",color:"primary",onClick:s},"Change Password"))):null}var sn=Object.defineProperty,mt=Object.prototype.hasOwnProperty,ae=Object.getOwnPropertySymbols,ft=Object.prototype.propertyIsEnumerable,pt=(e,t,r)=>t in e?sn(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r,cn=(e,t)=>{for(var r in t||(t={}))mt.call(t,r)&&pt(e,r,t[r]);if(ae)for(var r of ae(t))ft.call(t,r)&&pt(e,r,t[r]);return e},un=(e,t)=>{var r={};for(var a in e)mt.call(e,a)&&t.indexOf(a)<0&&(r[a]=e[a]);if(e!=null&&ae)for(var a of ae(e))t.indexOf(a)<0&&ft.call(e,a)&&(r[a]=e[a]);return r};function vt(e){var{name:t,terraAddress:r,designs:a,design:l,onChange:c,ref:f}=e,d=un(e,["name","terraAddress","designs","design","onChange","ref"]);const s=(0,n.useMemo)(()=>a.findIndex(m=>m===l),[l,a]),i=(0,n.useCallback)(m=>{c(a[m])},[a,c]);return n.createElement(Ve,cn({selectedIndex:s,onSelect:i,onCreate:()=>{}},d),a.map(m=>n.createElement(qe,{name:t,terraAddress:r,design:m})))}var dn=(e,t,r)=>new Promise((a,l)=>{var c=s=>{try{d(r.next(s))}catch(i){l(i)}},f=s=>{try{d(r.throw(s))}catch(i){l(i)}},d=s=>s.done?a(s.value):Promise.resolve(s.value).then(c,f);d((r=r.apply(e,t)).next())});function mn({history:e}){const[t,r]=(0,n.useState)(""),[a,l]=(0,n.useState)(()=>X[Math.floor(Math.random()*X.length)]),[c,f]=(0,n.useState)(""),d=(0,n.useMemo)(()=>_r(),[]),s=(0,n.useCallback)(()=>dn(this,null,function*(){const i=ct(d),m={name:t,design:a,terraAddress:d.accAddress,encryptedWallet:fe(i,c)};yield Je(m),e.push("/")}),[a,e,d,t,c]);return n.createElement(me,null,n.createElement("header",null,n.createElement("h1",null,"Add New Wallet"),n.createElement(vt,{style:{margin:"1em auto 3em auto"},name:t,design:a,terraAddress:"XXXXXXXXXXXXXXXXXXXXXXX",designs:X,onChange:l,cardWidth:276})),n.createElement(de,null,n.createElement(z.Z,{type:"text",size:"small",label:"WALLET NAME",InputLabelProps:{shrink:!0},value:t,onChange:({target:i})=>r(i.value)}),n.createElement(z.Z,{type:"password",size:"small",label:"WALLET PASSWORD",InputLabelProps:{shrink:!0},value:c,onChange:({target:i})=>f(i.value)})),n.createElement(fn,{style:{margin:"1em 0"}},d.mnemonic),n.createElement("footer",null,n.createElement(W.Z,{variant:"contained",color:"secondary",component:A.rU,to:"/"},"Cancel"),n.createElement(W.Z,{variant:"contained",color:"primary",onClick:s},"Create Wallet")))}const fn=v.ZP.section`
  border: 1px solid red;
  border-radius: 12px;

  padding: 1em;
`;var pn=(e,t,r)=>new Promise((a,l)=>{var c=s=>{try{d(r.next(s))}catch(i){l(i)}},f=s=>{try{d(r.throw(s))}catch(i){l(i)}},d=s=>s.done?a(s.value):Promise.resolve(s.value).then(c,f);d((r=r.apply(e,t)).next())});function vn({history:e}){const[t,r]=(0,n.useState)(""),[a,l]=(0,n.useState)(()=>X[Math.floor(Math.random()*X.length)]),[c,f]=(0,n.useState)(""),[d,s]=(0,n.useState)(""),i=(0,n.useCallback)(()=>pn(this,null,function*(){const m=en(d),O=ct(m),h={name:t,design:a,terraAddress:m.accAddress,encryptedWallet:fe(O,c)};yield Je(h),e.push("/")}),[a,e,d,t,c]);return n.createElement(me,null,n.createElement("header",null,n.createElement("h1",null,"Recover Existing Wallet"),n.createElement(vt,{style:{margin:"1em auto 3em auto"},name:t,design:a,terraAddress:"XXXXXXXXXXXXXXXXXXXXXXX",designs:X,onChange:l,cardWidth:276})),n.createElement(de,null,n.createElement(z.Z,{type:"text",size:"small",label:"WALLET NAME",InputLabelProps:{shrink:!0},value:t,onChange:({target:m})=>r(m.value)}),n.createElement(z.Z,{type:"password",size:"small",label:"WALLET PASSWORD",InputLabelProps:{shrink:!0},value:c,onChange:({target:m})=>f(m.value)}),n.createElement(z.Z,{type:"text",multiline:!0,size:"small",label:"MNEMONIC KEY",InputLabelProps:{shrink:!0},value:d,onChange:({target:m})=>s(m.value)})),n.createElement("footer",null,n.createElement(W.Z,{variant:"contained",color:"secondary",component:A.rU,to:"/"},"Cancel"),n.createElement(W.Z,{variant:"contained",color:"primary",onClick:i},"Recover Wallet")))}var hn=Object.defineProperty,gn=Object.prototype.hasOwnProperty,ht=Object.getOwnPropertySymbols,yn=Object.prototype.propertyIsEnumerable,gt=(e,t,r)=>t in e?hn(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r,wn=(e,t)=>{for(var r in t||(t={}))gn.call(t,r)&&gt(e,r,t[r]);if(ht)for(var r of ht(t))yn.call(t,r)&&gt(e,r,t[r]);return e};const bn=(0,E.Z)({typography:{button:{textTransform:"none"}}});function xn({children:e}){const[t,r]=(0,n.useState)(()=>N[0]),a=(0,n.useMemo)(()=>/^columbus/.test(t.chainID),[t.chainID]),l=(0,n.useMemo)(()=>a?jt:Wt,[a]),c=(0,n.useMemo)(()=>new b.AddressProviderFromJson(l),[l]),f=(0,n.useMemo)(()=>{const s=new w.HttpLink({uri:({operationName:i})=>{var m;return`${(m=t.servers.mantle)!=null?m:"https://tequila-mantle.anchorprotocol.com"}?${i}`}});return new y.fe({cache:new y.h4,link:s})},[t.servers.mantle]),d=(0,n.useMemo)(()=>a?{gasFee:1e6,fixedGas:5e5,blocksPerYear:4906443,gasAdjustment:1.6}:{gasFee:6e6,fixedGas:35e5,blocksPerYear:4906443,gasAdjustment:1.4},[a]);return(0,n.useEffect)(()=>{const s=ke().subscribe(({selectedNetwork:i})=>{r(i!=null?i:N[0])});return()=>{s.unsubscribe()}},[]),n.createElement(Ot,wn({},d),n.createElement(At,{addressProvider:c,addressMap:l},n.createElement(w.ApolloProvider,{client:f},e)))}function En({className:e}){const{locale:t,messages:r}=Gt(),a=(0,S.TH)(),l=(0,n.useRef)(null);return(0,n.useEffect)(()=>{var c;(c=l.current)==null||c.scrollTo({top:0,behavior:"smooth"})},[a.pathname]),(0,n.useEffect)(()=>{setTimeout(()=>{!l.current||(l.current.style.minHeight=D+"px",l.current.style.maxHeight=D+"px")},2e3)},[]),n.createElement(xn,null,n.createElement(Tt.Z,{locale:t,messages:r},n.createElement(ir,{theme:bn},n.createElement("div",{className:e},n.createElement(or,null),n.createElement("section",{ref:l},n.createElement(S.rs,null,n.createElement(S.AW,{exact:!0,path:"/",component:Qr}),n.createElement(S.AW,{path:"/wallet/create",component:mn}),n.createElement(S.AW,{path:"/wallet/recover",component:vn}),n.createElement(S.AW,{path:"/wallets/:terraAddress/password",component:on}),n.createElement(S.AW,{path:"/network/create",component:Jr}),n.createElement(S.l_,{to:"/"}))),n.createElement(kt,null)))))}const kn=v.F4`
  0% {
    transform: translateY(-${j}px);
  }
  
  30% {
    transform: translateY(-${j}px);
  }
  
  100% {
    transform: translateY(0);
  }
`,Cn=(0,v.ZP)(En)`
  min-width: ${Ut}px;
  min-height: ${j+D}px;
  max-height: ${j+D}px;

  display: flex;
  flex-direction: column;

  > section {
    min-height: ${j+D}px;
    max-height: ${j+D}px;
    padding: 20px;

    ${P};

    background-color: #ffffff;

    border-top-left-radius: 24px;
    border-top-right-radius: 24px;

    box-shadow: 0px 4px 18px 3px rgba(0, 0, 0, 0.33);

    animation: ${kn} 0.6s ease-in;
  }
`;(0,zt.render)(n.createElement(A.UT,null,n.createElement(Mt,null,n.createElement(Kt,null,n.createElement(Cn,null)))),document.querySelector("#app"))},78693:u=>{u.exports={"wallet.change-password":"Change password","wallet.delete":"Delete wallet","wallet.recover":"Recover existing wallet","wallet.new":"New wallet","wallet.empty":"Please add a new wallet","locale.en-US":"English","locale.ko-KR":"Korean"}},80082:u=>{u.exports={"wallet.change-password":"\uBE44\uBC00\uBC88\uD638 \uBCC0\uACBD","wallet.delete":"\uC9C0\uAC11 \uC0AD\uC81C","wallet.recover":"\uAE30\uC874 \uC9C0\uAC11 \uBCF5\uC6D0\uD558\uAE30","wallet.new":"\uC0C8 \uC9C0\uAC11","wallet.empty":"\uC9C0\uAC11\uC774 \uC5C6\uC2B5\uB2C8\uB2E4. \uC0C8 \uC9C0\uAC11\uC744 \uB9CC\uB4E4\uC5B4\uC8FC\uC138\uC694."}},58554:()=>{},4813:()=>{},45545:()=>{},46047:()=>{},78028:()=>{},50695:()=>{},84215:()=>{},47021:()=>{},24318:()=>{},3967:()=>{},73927:()=>{},77702:()=>{}},ve={};function p(u){var g=ve[u];if(g!==void 0)return g.exports;var o=ve[u]={id:u,loaded:!1,exports:{}};return pe[u].call(o.exports,o,o.exports,p),o.loaded=!0,o.exports}p.m=pe,(()=>{var u=[];p.O=(g,o,b,w)=>{if(o){w=w||0;for(var y=u.length;y>0&&u[y-1][2]>w;y--)u[y]=u[y-1];u[y]=[o,b,w];return}for(var E=Infinity,y=0;y<u.length;y++){for(var[o,b,w]=u[y],v=!0,P=0;P<o.length;P++)(w&!1||E>=w)&&Object.keys(p.O).every(C=>p.O[C](o[P]))?o.splice(P--,1):(v=!1,w<E&&(E=w));v&&(u.splice(y--,1),g=b())}return g}})(),(()=>{p.n=u=>{var g=u&&u.__esModule?()=>u.default:()=>u;return p.d(g,{a:g}),g}})(),(()=>{var u=Object.getPrototypeOf?o=>Object.getPrototypeOf(o):o=>o.__proto__,g;p.t=function(o,b){if(b&1&&(o=this(o)),b&8||typeof o=="object"&&o&&(b&4&&o.__esModule||b&16&&typeof o.then=="function"))return o;var w=Object.create(null);p.r(w);var y={};g=g||[null,u({}),u([]),u(u)];for(var E=b&2&&o;typeof E=="object"&&!~g.indexOf(E);E=u(E))Object.getOwnPropertyNames(E).forEach(v=>y[v]=()=>o[v]);return y.default=()=>o,p.d(w,y),w}})(),(()=>{p.d=(u,g)=>{for(var o in g)p.o(g,o)&&!p.o(u,o)&&Object.defineProperty(u,o,{enumerable:!0,get:g[o]})}})(),(()=>{p.g=function(){if(typeof globalThis=="object")return globalThis;try{return this||new Function("return this")()}catch(u){if(typeof window=="object")return window}}()})(),(()=>{p.hmd=u=>(u=Object.create(u),u.children||(u.children=[]),Object.defineProperty(u,"exports",{enumerable:!0,set:()=>{throw new Error("ES Modules may not assign module.exports or exports.*, Use ESM export syntax, instead: "+u.id)}}),u)})(),(()=>{p.o=(u,g)=>Object.prototype.hasOwnProperty.call(u,g)})(),(()=>{p.r=u=>{typeof Symbol!="undefined"&&Symbol.toStringTag&&Object.defineProperty(u,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(u,"__esModule",{value:!0})}})(),(()=>{p.nmd=u=>(u.paths=[],u.children||(u.children=[]),u)})(),(()=>{p.j=42})(),(()=>{p.p=""})(),(()=>{var u={42:0};p.O.j=b=>u[b]===0;var g=(b,w)=>{var[y,E,v]=w,P,I,$=0;for(P in E)p.o(E,P)&&(p.m[P]=E[P]);for(v&&v(p),b&&b(w);$<y.length;$++)I=y[$],p.o(u,I)&&u[I]&&u[I][0](),u[y[$]]=0;p.O()},o=self.webpackChunkweb_template=self.webpackChunkweb_template||[];o.forEach(g.bind(null,0)),o.push=g.bind(null,o.push.bind(o))})();var he=p.O(void 0,[736],()=>p(50018));he=p.O(he)})();

//# sourceMappingURL=popup.b1c34a51d9d19e06073c.js.map